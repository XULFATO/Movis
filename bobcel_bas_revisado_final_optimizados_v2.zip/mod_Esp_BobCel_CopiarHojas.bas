Attribute VB_Name = "mod_Esp_BobCel_CopiarHojas"
Option Explicit
Public Function CrearLibroHijoDesdePadre(ByVal wbOrigen As Workbook) As Workbook
    Dim arrHojas() As String
    Dim total As Long
    Dim ws As Worksheet
    Dim wbNuevo As Workbook
    Dim estabaProtegidoEstructura As Boolean
    Dim oldDisplayAlerts As Boolean
    On Error GoTo ErrHandler
    oldDisplayAlerts = Application.DisplayAlerts
    Application.DisplayAlerts = False
    total = 0
    estabaProtegidoEstructura = wbOrigen.ProtectStructure
    ' Si el libro padre tiene la estructura protegida, no siempre deja copiar hojas.
    ' Se desprotege temporalmente y se vuelve a dejar como estaba al final.
    If estabaProtegidoEstructura Then
        Call DesprotegerLibro(wbOrigen)
        If wbOrigen.ProtectStructure Then
            Err.Raise vbObjectError + 3001, , _
                "No se pueden copiar las hojas porque el libro padre tiene la estructura protegida " & _
                "y no se pudo desproteger con PASS_LIBRO."
        End If
    End If
    For Each ws In wbOrigen.Worksheets
        If Not EsHojaExcluida(ws.Name) Then
            total = total + 1
            ReDim Preserve arrHojas(1 To total)
            arrHojas(total) = ws.Name
        End If
    Next ws
    If total = 0 Then
        Err.Raise vbObjectError + 3000, , _
            "No hay hojas para copiar. Revisa HOJAS_EXCLUIDAS."
    End If
    ' Copia EN BLOQUE.
    ' Esto crea automaticamente un libro nuevo con todas las hojas seleccionadas.
    wbOrigen.Worksheets(arrHojas).Copy
    Set wbNuevo = ActiveWorkbook
    ' Si quieres proteger tambien la estructura del hijo, se controla desde Config.
    If PROTEGER_LIBRO_HIJO_ESTRUCTURA Then
        Call ProtegerLibro(wbNuevo)
    End If
    If estabaProtegidoEstructura And PROTEGER_LIBRO_PADRE_AL_FINAL Then
        Call ProtegerLibro(wbOrigen)
    End If
    Application.DisplayAlerts = oldDisplayAlerts
    Set CrearLibroHijoDesdePadre = wbNuevo
    Exit Function
ErrHandler:
    On Error Resume Next
    If Not wbNuevo Is Nothing Then
        wbNuevo.Close SaveChanges:=False
    End If
    If estabaProtegidoEstructura And PROTEGER_LIBRO_PADRE_AL_FINAL Then
        Call ProtegerLibro(wbOrigen)
    End If
    Application.DisplayAlerts = oldDisplayAlerts
    Err.Raise Err.Number, Err.Source, Err.Description
End Function
