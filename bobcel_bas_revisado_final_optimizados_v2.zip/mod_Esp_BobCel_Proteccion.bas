Attribute VB_Name = "mod_Esp_BobCel_Proteccion"
Option Explicit
' =====================================================
' PROTECCION DE HOJAS
' =====================================================
Public Sub DesprotegerHoja(ByVal ws As Worksheet)
    On Error Resume Next
    ws.Unprotect Password:=PASS_HOJA
    ws.Unprotect
    On Error GoTo 0
End Sub
Public Sub ProtegerHoja(ByVal ws As Worksheet)
    On Error Resume Next
    ws.Protect Password:=PASS_HOJA, _
               DrawingObjects:=True, _
               Contents:=True, _
               Scenarios:=True, _
               AllowFormattingCells:=True, _
               AllowFormattingColumns:=True, _
               AllowFormattingRows:=True, _
               AllowInsertingColumns:=False, _
               AllowInsertingRows:=False, _
               AllowDeletingColumns:=False, _
               AllowDeletingRows:=False, _
               AllowSorting:=True, _
               AllowFiltering:=True, _
               AllowUsingPivotTables:=True
    ws.EnableSelection = xlNoRestrictions
    On Error GoTo 0
End Sub
' =====================================================
' PROTECCION DE ESTRUCTURA DEL LIBRO
' Esto afecta a copiar, mover, borrar, ocultar y renombrar pestanas.
' No tiene nada que ver con la password del VBProject.
' =====================================================
Public Sub DesprotegerLibro(ByVal wb As Workbook)
    On Error Resume Next
    wb.Unprotect Password:=PASS_LIBRO
    wb.Unprotect
    On Error GoTo 0
End Sub
Public Sub ProtegerLibro(ByVal wb As Workbook)
    On Error Resume Next
    wb.Protect Password:=PASS_LIBRO, Structure:=True, Windows:=False
    On Error GoTo 0
End Sub
Public Function LibroTieneEstructuraProtegida(ByVal wb As Workbook) As Boolean
    On Error Resume Next
    LibroTieneEstructuraProtegida = wb.ProtectStructure
    On Error GoTo 0
End Function
