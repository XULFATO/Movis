Attribute VB_Name = "mod_Esp_BobCel_EventosEmbebidos"
Option Explicit
Public Sub InsertarEventoThisWorkbookBeforeSave(ByVal wb As Workbook)
    Dim comp As Object
    Dim cm As Object
    Dim codigo As String
    If Not PuedeAccederVBProject(wb) Then
        Err.Raise vbObjectError + 2200, , _
            "No se puede insertar el evento ThisWorkbook en el libro hijo."
    End If
    Set comp = wb.VBProject.VBComponents("ThisWorkbook")
    Set cm = comp.CodeModule
    Call BorrarCodigoModulo(cm)
    codigo = "Option Explicit" & vbCrLf
    codigo = codigo & vbCrLf
    codigo = codigo & "Private Sub Workbook_BeforeSave(ByVal SaveAsUI As Boolean, Cancel As Boolean)" & vbCrLf
    codigo = codigo & "    Cancel = True" & vbCrLf
    codigo = codigo & "    Call Mod_GuardarArchivo.GuardarArchivo" & vbCrLf
    codigo = codigo & "End Sub" & vbCrLf
    ' Eliminado AddFromString hardcodeado
End Sub
Private Sub BorrarCodigoModulo(ByVal cm As Object)
    On Error Resume Next
    If cm.CountOfLines > 0 Then
        cm.DeleteLines 1, cm.CountOfLines
    End If
    On Error GoTo 0
End Sub
