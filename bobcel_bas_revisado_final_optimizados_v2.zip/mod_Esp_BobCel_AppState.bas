Attribute VB_Name = "mod_Esp_BobCel_AppState"
Option Explicit
' Modulo reservado para centralizar estado de Excel si se decide quitarlo del Main.
' De momento el Main conserva el guardado/restauracion local para maxima claridad.
