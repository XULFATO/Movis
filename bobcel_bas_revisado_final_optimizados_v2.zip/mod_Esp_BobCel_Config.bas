Attribute VB_Name = "mod_Esp_BobCel_Config"
Option Explicit
' =====================================================
' 00 - PANEL DE CONTROL BOB / CELERGO
' =====================================================
' Este modulo debe permitir entender de un vistazo:
' - que hojas usa el sistema
' - que hojas viajan al hijo
' - que hojas se ocultan en el padre
' - que hojas se borran del hijo
' - que modulos se copian al hijo
' - que opciones estan activadas
' =====================================================
' =====================================================
' 01 - RUTAS Y NOMBRES DE INFORME
' =====================================================
Public Const RUTA_DESTINO As String = "C:\clientes\bp\"
Public Const NOMBRE_BOB As String = "Informe_BOB"
Public Const NOMBRE_CELERGO As String = "Informe_CELERGO"
' =====================================================
' 02 - CLIENTES / MARCAS
' =====================================================
Public Const MARCA_BOB As String = "BOB"
Public Const MARCA_CELERGO As String = "CELERGO"
Public Const MARCA_AMBOS As String = "BOB/CELERGO"
' =====================================================
' 03 - PASSWORDS
' =====================================================
Public Const PASS_HOJA As String = "ADP"
Public Const PASS_LIBRO As String = "ADP"
' =====================================================
' 04 - HOJAS PRINCIPALES
' =====================================================
Public Const HOJA_COLUMNAS As String = "Analisis conceptos"
Public Const HOJA_FILAS As String = "Preg Generales - Propuesta 2"
Public Const HOJA_BASIC As String = "BASIC"
Public Const HOJA_COMPLEMENTO_IT As String = "Complemento IT"
' =====================================================
' 05 - CONFIGURACION DE ANALISIS CONCEPTOS
' =====================================================
Public Const HOJA_COLUMNAS_FILA_MARCA As Long = 2
Public Const HOJA_COLUMNAS_FILA_CABECERA As Long = 4
Public Const HOJA_COLUMNAS_FILA_INICIO_DATOS As Long = 5
' =====================================================
' 06 - CONFIGURACION DE PREG GENERALES
' =====================================================
Public Const HOJA_FILAS_COL_MARCA As String = "E"
Public Const HOJA_FILAS_FILA_INICIO As Long = 4
Public Const HOJA_FILAS_FILA_CABECERA As Long = 3
Public Const HOJA_FILAS_CELDA_COMPLEMENTO_IT As String = "C25"
' =====================================================
' 07 - HOJAS CFG / TECNICAS
' =====================================================
Public Const HOJA_CFG_REGLAS As String = "CFG_REGLAS"
Public Const HOJA_CFG_FORMULAS As String = "CFG_FORMULAS"
Public Const HOJA_CFG_COLORES As String = "CFG_COLORES"
Public Const HOJA_MAPA_COLUMNAS As String = "CFG_MAPA_COLUMNAS"
Public Const HOJA_MAPA_COLUMNAS_BOB As String = "CFG_MAPA_COLUMNAS_BOB"
Public Const HOJA_MAPA_COLUMNAS_CELERGO As String = "CFG_MAPA_COLUMNAS_CELERGO"
Public Const HOJA_CFG_REGLAS_BOB As String = "CFG_REGLAS_BOB"
Public Const HOJA_CFG_REGLAS_CELERGO As String = "CFG_REGLAS_CELERGO"
Public Const HOJA_CFG_FORMULAS_BOB As String = "CFG_FORMULAS_BOB"
Public Const HOJA_CFG_FORMULAS_CELERGO As String = "CFG_FORMULAS_CELERGO"
' =====================================================
' 08 - HOJAS QUE NO SE COPIAN AL HIJO
' =====================================================
' Aqui van hojas que el hijo nunca necesita.
' Si una hoja hace falta durante el proceso, NO la pongas aqui.
' Ponla en HOJAS_TECNICAS_HIJO_BORRAR.
' =====================================================
Public Const HOJAS_EXCLUIDAS As String = ""
' =====================================================
' 09 - HOJAS TECNICAS QUE SE OCULTAN EN EL PADRE
' =====================================================
' Se quedan en el padre para revisar/depurar,
' pero ocultas como VeryHidden.
' =====================================================
Public Const HOJAS_TECNICAS_PADRE_OCULTAR As String = _
    "CFG_MAPA_COLUMNAS_CELERGO|" & _
    "CFG_REGLAS_CELERGO|" & _
    "CFG_FORMULAS_CELERGO|" & _
    "CFG_MAPA_COLUMNAS|" & _
    "CFG_REGLAS_BOB|" & _
    "CFG_FORMULAS_BOB"
' =====================================================
' 10 - HOJAS TECNICAS QUE SE BORRAN DEL HIJO
' =====================================================
' Estas hojas pueden viajar temporalmente al hijo porque hacen falta
' para aplicar formulas/reglas, pero NO deben quedar en el informe final.
'
' IMPORTANTE:
' No borrar BASIC si las formulas finales siguen apuntando a BASIC.
' =====================================================
Public Const HOJAS_TECNICAS_HIJO_BORRAR As String = _
    "CFG_MAPA_COLUMNAS_CELERGO|" & _
    "CFG_REGLAS_CELERGO|" & _
    "CFG_FORMULAS_CELERGO|" & _
    "Menu2|" & _
    "CFG_MAPA_COLUMNAS|" & _
    "CFG_REGLAS_BOB|" & _
    "CFG_FORMULAS_BOB|" & _
    "CFG_REGLAS|" & _
    "CFG_FORMULAS|" & _
    "CFG_COLORES"
' =====================================================
' 11 - MODULOS QUE SE COPIAN AL HIJO
' =====================================================
' Se copian desde el Excel padre real, no desde codigo incrustado.
' No meter ThisWorkbook ni hojas aqui.
' =====================================================
Public Const MODULOS_CONSERVAR As String = _
    "mod_Mostrar_Hoja_Complemento_IT|" & _
    "Mod_GuardarArchivo|" & _
    "mod_1B_FC_PintarColorCFG"
' =====================================================
' 12 - FLAGS DE COMPORTAMIENTO
' =====================================================
Public Const USAR_MOTOR_CFG_POR_CABECERAS As Boolean = True
Public Const APLICAR_CFG_ADAPTADAS_EN_HIJO As Boolean = True
Public Const QUITAR_ENLACES_EXTERNOS As Boolean = True
Public Const INSERTAR_MODULOS_PERMITIDOS As Boolean = True
Public Const INSERTAR_EVENTO_BEFORESAVE As Boolean = True
Public Const CFG_ADAPTADAS_BORRAR_ANTES As Boolean = True
Public Const CFG_MAPAS_VISIBLES As Boolean = False
Public Const CFG_APLICAR_BORRAR_FC_PREVIAS As Boolean = True
Public Const CFG_OCULTAR_TECNICAS_EN_HIJO As Boolean = False
Public Const PROTEGER_LIBRO_PADRE_AL_FINAL As Boolean = True
Public Const PROTEGER_LIBRO_HIJO_ESTRUCTURA As Boolean = False
Public Const APLICAR_FREEZE_HIJO As Boolean = False
Public Const APLICAR_BLOQUEOS_HIJO As Boolean = False
Public Const USAR_LOG_BOBCEL As Boolean = False
' =====================================================
' 13 - CFG_REGLAS: COLUMNAS DE CONFIGURACION
' =====================================================
Public Const CFG_REGLAS_FILA_INICIO As Long = 2
Public Const CFG_REGLAS_COL_ACTIVA As String = "A"
Public Const CFG_REGLAS_COL_ORDEN As String = "B"
Public Const CFG_REGLAS_COL_NOMBRE As String = "C"
Public Const CFG_REGLAS_COL_RANGO_APLICA As String = "D"
Public Const CFG_REGLAS_COL_FORMULA As String = "E"
Public Const CFG_REGLAS_COL_COLOR_FONDO As String = "F"
Public Const CFG_REGLAS_COL_COLOR_FUENTE As String = "G"
Public Const CFG_REGLAS_COL_NEGRITA As String = "H"
Public Const CFG_REGLAS_COL_STOP_IF_TRUE As String = "I"
Public Const CFG_REGLAS_COL_TACHADO As String = "J"
Public Const CFG_REGLAS_COL_BORDE_FINO As String = "K"
Public Const CFG_REGLAS_COL_COMENTARIO As String = "L"
Public Const CFG_REGLAS_COL_EXPLICA_RANGO As String = "M"
Public Const CFG_REGLAS_COL_EXPLICA_FORMULA As String = "N"
Public Const CFG_REGLAS_COL_RESULTADO As String = "O"
' =====================================================
' 14 - CFG_FORMULAS: COLUMNAS DE CONFIGURACION
' =====================================================
Public Const CFG_FORMULAS_FILA_INICIO As Long = 2
Public Const CFG_FORMULAS_COL_ACTIVA As String = "A"
Public Const CFG_FORMULAS_COL_ORDEN As String = "B"
Public Const CFG_FORMULAS_COL_COLUMNA_DESTINO As String = "C"
Public Const CFG_FORMULAS_COL_RANGO_DESTINO As String = "D"
Public Const CFG_FORMULAS_COL_FORMULA As String = "E"
Public Const CFG_FORMULAS_COL_COMENTARIO As String = "F"
' =====================================================
' 15 - EVENTOS / AUXILIARES
' =====================================================
Public Const CFG_REGLAS_RANGO_CHANGE As String = "F:G"
Public Const CFG_REGLAS_FILA_INICIO_DATOS As Long = 2
Public Const CFG_REGLAS_COL_ORIGEN As String = "F"
Public Const CFG_REGLAS_COL_DESTINO As String = "G"
