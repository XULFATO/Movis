Attribute VB_Name = "mod_Esp_BobCel_Bloqueo"
Option Explicit
Public Sub ConfigurarBloqueosHijo(ByVal wb As Workbook)
    ' Punto unico para bloqueos de rangos/celdas del hijo.
    ' Se activa con APLICAR_BLOQUEOS_HIJO = True.
    ' Ahora no cambia nada para evitar efectos secundarios.
End Sub
