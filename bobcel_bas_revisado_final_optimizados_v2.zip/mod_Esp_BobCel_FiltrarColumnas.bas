Attribute VB_Name = "mod_Esp_BobCel_FiltrarColumnas"
Option Explicit
Public Sub FiltrarColumnasPorCliente(ByVal wb As Workbook, ByVal cliente As String)
    Dim ws As Worksheet
    Dim ultimaCol As Long
    Dim col As Long
    Dim marca As String
    On Error GoTo ErrHandler
    If Not HojaExiste(wb, HOJA_COLUMNAS) Then
        Err.Raise vbObjectError + 1200, , _
            "No existe la hoja de columnas: " & HOJA_COLUMNAS
    End If
    Set ws = wb.Worksheets(HOJA_COLUMNAS)
    Call DesprotegerHoja(ws)
    If ws.ProtectContents Then
        Err.Raise vbObjectError + 1201, , _
            "No se pudo desproteger la hoja: " & HOJA_COLUMNAS
    End If
    ultimaCol = UltimaColumnaUsada(ws)
    For col = ultimaCol To 1 Step -1
        marca = NormalizarMarca(ws.Cells(HOJA_COLUMNAS_FILA_MARCA, col).Value)
        If Not DebeConservarPorMarca(marca, cliente) Then
            ws.Columns(col).Delete
        End If
    Next col
    ws.Rows(HOJA_COLUMNAS_FILA_MARCA).ClearContents
    Call ProtegerHoja(ws)
    Exit Sub
ErrHandler:
    On Error Resume Next
    If Not ws Is Nothing Then Call ProtegerHoja(ws)
    On Error GoTo 0
    Err.Raise Err.Number, Err.Source, Err.Description
End Sub
