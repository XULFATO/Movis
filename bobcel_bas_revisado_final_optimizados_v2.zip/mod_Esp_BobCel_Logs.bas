Attribute VB_Name = "mod_Esp_BobCel_Logs"
Option Explicit
Private Const HOJA_LOG As String = "LOG_BOBCEL"
Public Sub LogInfo(ByVal texto As String)
    EscribirLog "INFO", texto
End Sub
Public Sub LogOk(ByVal texto As String)
    EscribirLog "OK", texto
End Sub
Public Sub LogError(ByVal texto As String)
    EscribirLog "ERROR", texto
End Sub
Private Sub EscribirLog(ByVal estado As String, ByVal texto As String)
    Dim ws As Worksheet, f As Long
    If Not USAR_LOG_BOBCEL Then Exit Sub
    Set ws = ObtenerHojaLog(ThisWorkbook)
    f = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row + 1
    ws.Cells(f, "A").Value = Now
    ws.Cells(f, "B").Value = estado
    ws.Cells(f, "C").Value = texto
End Sub
Private Function ObtenerHojaLog(ByVal wb As Workbook) As Worksheet
    If Not HojaExiste(wb, HOJA_LOG) Then
        Set ObtenerHojaLog = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
        ObtenerHojaLog.Name = HOJA_LOG
        ObtenerHojaLog.Range("A1:C1").Value = Array("Fecha", "Estado", "Detalle")
    Else
        Set ObtenerHojaLog = wb.Worksheets(HOJA_LOG)
    End If
End Function
