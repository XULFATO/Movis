Attribute VB_Name = "mod_Esp_BobCel_CopiarModulosPadre"
Option Explicit
' =====================================================
' COPIA MODULOS REALES DEL PADRE AL HIJO
'
' Ademas limpia del hijo cualquier modulo estandar/clase/form
' que NO este en MODULOS_CONSERVAR.
'
' No toca:
' - ThisWorkbook
' - modulos de hoja
' porque son componentes documentales Type = 100.
' =====================================================
Public Sub CopiarModulosPermitidosDesdePadre(ByVal wbPadre As Workbook, ByVal wbHijo As Workbook)
    Dim arr() As String
    Dim i As Long
    Dim nombreModulo As String
    Dim rutaTemp As String
    On Error GoTo ErrHandler
    If Not PuedeAccederVBProject(wbPadre) Then
        Err.Raise vbObjectError + 9100, , _
            "No se puede acceder al VBProject del libro padre." & vbCrLf & _
            "Revisa Centro de confianza y que el proyecto VBA del padre este desbloqueado."
    End If
    If Not PuedeAccederVBProject(wbHijo) Then
        Err.Raise vbObjectError + 9101, , _
            "No se puede acceder al VBProject del libro hijo." & vbCrLf & _
            "Revisa Centro de confianza."
    End If
    ' Primero limpiamos el hijo por si viene de una copia que arrastra modulos del padre.
    Call EliminarModulosNoPermitidosHijo(wbHijo)
    rutaTemp = Environ$("TEMP") & "\BobCel_TempBas_" & Format(Now, "yyyymmdd_hhnnss") & "\"
    Call CrearCarpetaSiNoExiste(rutaTemp)
    arr = Split(MODULOS_CONSERVAR, "|")
    For i = LBound(arr) To UBound(arr)
        nombreModulo = Trim$(CStr(arr(i)))
        If Len(nombreModulo) > 0 Then
            Call CopiarModuloPadreAHijo(wbPadre, wbHijo, nombreModulo, rutaTemp)
        End If
    Next i
    ' Segunda limpieza defensiva: si algo no permitido ha quedado, fuera.
    Call EliminarModulosNoPermitidosHijo(wbHijo)
Salida:
    Call BorrarCarpetaTemporalBas(rutaTemp)
    Exit Sub
ErrHandler:
    Dim nErr As Long
    Dim dErr As String
    nErr = Err.Number
    dErr = Err.Description
    On Error Resume Next
    Call BorrarCarpetaTemporalBas(rutaTemp)
    On Error GoTo 0
    Err.Raise nErr, "CopiarModulosPermitidosDesdePadre", dErr
End Sub
Public Sub EliminarModulosNoPermitidosHijo(ByVal wbHijo As Workbook)
    Dim i As Long
    Dim comp As Object
    Dim nombreModulo As String
    If Not PuedeAccederVBProject(wbHijo) Then
        Err.Raise vbObjectError + 9130, , _
            "No se puede acceder al VBProject del libro hijo para limpiar modulos no permitidos."
    End If
    For i = wbHijo.VBProject.VBComponents.Count To 1 Step -1
        Set comp = wbHijo.VBProject.VBComponents(i)
        nombreModulo = comp.Name
        Select Case comp.Type
            Case 1, 2, 3
                ' 1 = modulo estandar
                ' 2 = clase
                ' 3 = formulario
                If Not EsModuloPermitidoEnHijo(nombreModulo) Then
                    wbHijo.VBProject.VBComponents.Remove comp
                End If
            Case 100
                ' Componentes documentales: ThisWorkbook / hojas.
                ' No se eliminan aqui.
        End Select
    Next i
End Sub
Private Function EsModuloPermitidoEnHijo(ByVal nombreModulo As String) As Boolean
    Dim arr() As String
    Dim i As Long
    Dim item As String
    arr = Split(MODULOS_CONSERVAR, "|")
    For i = LBound(arr) To UBound(arr)
        item = Trim$(CStr(arr(i)))
        If Len(item) > 0 Then
            If StrComp(item, nombreModulo, vbTextCompare) = 0 Then
                EsModuloPermitidoEnHijo = True
                Exit Function
            End If
        End If
    Next i
End Function
Private Sub CopiarModuloPadreAHijo(ByVal wbPadre As Workbook, _
                                   ByVal wbHijo As Workbook, _
                                   ByVal nombreModulo As String, _
                                   ByVal rutaTemp As String)
    Dim compPadre As Object
    Dim rutaExport As String
    On Error Resume Next
    Set compPadre = wbPadre.VBProject.VBComponents(nombreModulo)
    On Error GoTo 0
    If compPadre Is Nothing Then
        Err.Raise vbObjectError + 9110, , _
            "No existe en el padre el modulo permitido:" & vbCrLf & nombreModulo
    End If
    If compPadre.Type = 100 Then
        Err.Raise vbObjectError + 9111, , _
            "No metas componentes documentales en MODULOS_CONSERVAR:" & vbCrLf & _
            nombreModulo & vbCrLf & _
            "ThisWorkbook y hojas se gestionan aparte."
    End If
    rutaExport = rutaTemp & NombreArchivoSeguro(nombreModulo) & ExtensionComponente(compPadre)
    If Len(Dir$(rutaExport)) > 0 Then Kill rutaExport
    compPadre.Export rutaExport
    Call BorrarComponenteSiExiste(wbHijo, nombreModulo)
    wbHijo.VBProject.VBComponents.Import rutaExport
End Sub
Private Function ExtensionComponente(ByVal comp As Object) As String
    Select Case comp.Type
        Case 1
            ExtensionComponente = ".bas"
        Case 2
            ExtensionComponente = ".cls"
        Case 3
            ExtensionComponente = ".frm"
        Case Else
            ExtensionComponente = ".bas"
    End Select
End Function
Private Sub BorrarComponenteSiExiste(ByVal wb As Workbook, ByVal nombreModulo As String)
    Dim comp As Object
    On Error Resume Next
    Set comp = wb.VBProject.VBComponents(nombreModulo)
    On Error GoTo 0
    If Not comp Is Nothing Then
        If comp.Type = 100 Then
            Err.Raise vbObjectError + 9120, , _
                "No se puede borrar/importar como modulo normal el componente documental:" & vbCrLf & _
                nombreModulo & vbCrLf & _
                "No lo incluyas en MODULOS_CONSERVAR."
        End If
        wb.VBProject.VBComponents.Remove comp
    End If
End Sub
Private Function PuedeAccederVBProject(ByVal wb As Workbook) As Boolean
    Dim n As Long
    On Error GoTo ErrHandler
    n = wb.VBProject.VBComponents.Count
    PuedeAccederVBProject = True
    Exit Function
ErrHandler:
    PuedeAccederVBProject = False
End Function
Private Sub CrearCarpetaSiNoExiste(ByVal ruta As String)
    If Len(ruta) = 0 Then Exit Sub
    If Len(Dir$(ruta, vbDirectory)) = 0 Then
        MkDir ruta
    End If
End Sub
Private Sub BorrarCarpetaTemporalBas(ByVal rutaTemp As String)
    Dim f As String
    If Len(rutaTemp) = 0 Then Exit Sub
    On Error Resume Next
    f = Dir$(rutaTemp & "*.*")
    Do While Len(f) > 0
        Kill rutaTemp & f
        f = Dir$()
    Loop
    RmDir rutaTemp
    On Error GoTo 0
End Sub
Private Function NombreArchivoSeguro(ByVal s As String) As String
    Dim i As Long
    Dim ch As String
    Dim salida As String
    s = Trim$(CStr(s))
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        Select Case ch
            Case "<", ">", ":", Chr$(34), "/", "\", "|", "?", "*"
                salida = salida & "_"
            Case Else
                salida = salida & ch
        End Select
    Next i
    If Len(Trim$(salida)) = 0 Then salida = "Modulo"
    NombreArchivoSeguro = salida
End Function
