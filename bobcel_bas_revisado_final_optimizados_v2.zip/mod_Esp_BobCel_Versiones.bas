Attribute VB_Name = "mod_Esp_BobCel_Versiones"
Option Explicit
Public Sub AsegurarCarpetas()
    CrearCarpetaCompleta RUTA_DESTINO
End Sub
Public Function SiguienteVersion(ByVal nombreBase As String) As String
    Dim i As Long
    Dim ruta As String
    For i = 1 To 9999
        ruta = RUTA_DESTINO & nombreBase & "_v" & CStr(i) & ".xlsm"
        If Dir$(ruta) = vbNullString Then
            SiguienteVersion = ruta
            Exit Function
        End If
    Next i
    Err.Raise vbObjectError + 1100, , _
        "No se pudo calcular version libre para: " & nombreBase
End Function
Private Sub CrearCarpetaCompleta(ByVal rutaCarpeta As String)
    Dim partes() As String
    Dim i As Long
    Dim rutaActual As String
    rutaCarpeta = Replace(rutaCarpeta, "/", "\")
    If Right$(rutaCarpeta, 1) = "\" Then
        rutaCarpeta = Left$(rutaCarpeta, Len(rutaCarpeta) - 1)
    End If
    partes = Split(rutaCarpeta, "\")
    If UBound(partes) < 0 Then Exit Sub
    rutaActual = partes(0)
    For i = 1 To UBound(partes)
        rutaActual = rutaActual & "\" & partes(i)
        If Len(Dir$(rutaActual, vbDirectory)) = 0 Then
            MkDir rutaActual
        End If
    Next i
End Sub
