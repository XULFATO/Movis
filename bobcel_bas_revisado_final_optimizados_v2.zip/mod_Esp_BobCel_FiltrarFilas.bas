Attribute VB_Name = "mod_Esp_BobCel_FiltrarFilas"
Option Explicit
Public Sub FiltrarFilasPorCliente(ByVal wb As Workbook, ByVal cliente As String)
    Dim ws As Worksheet
    Dim ultimaFila As Long
    Dim fila As Long
    Dim marca As String
    On Error GoTo ErrHandler
    If Not HojaExiste(wb, HOJA_FILAS) Then
        Err.Raise vbObjectError + 1100, , _
            "No existe la hoja de filas: " & HOJA_FILAS
    End If
    Set ws = wb.Worksheets(HOJA_FILAS)
    Call DesprotegerHoja(ws)
    If ws.ProtectContents Then
        Err.Raise vbObjectError + 1101, , _
            "No se pudo desproteger la hoja: " & HOJA_FILAS
    End If
    ultimaFila = ws.Cells(ws.Rows.Count, HOJA_FILAS_COL_MARCA).End(xlUp).Row
    If ultimaFila >= HOJA_FILAS_FILA_INICIO Then
        For fila = ultimaFila To HOJA_FILAS_FILA_INICIO Step -1
            marca = NormalizarMarca(ws.Cells(fila, HOJA_FILAS_COL_MARCA).Value)
            If Not DebeConservarPorMarca(marca, cliente) Then
                ws.Rows(fila).Delete
            End If
        Next fila
    End If
    ws.Columns(HOJA_FILAS_COL_MARCA).Delete
    Call ProtegerHoja(ws)
    Exit Sub
ErrHandler:
    On Error Resume Next
    If Not ws Is Nothing Then Call ProtegerHoja(ws)
    On Error GoTo 0
    Err.Raise Err.Number, Err.Source, Err.Description
End Sub
