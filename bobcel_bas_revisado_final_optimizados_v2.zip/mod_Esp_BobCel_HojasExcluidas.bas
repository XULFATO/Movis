Attribute VB_Name = "mod_Esp_BobCel_HojasExcluidas"
Option Explicit
Public Function EsHojaExcluida(ByVal nombreHoja As String) As Boolean
    Dim arr() As String
    Dim i As Long
    Dim item As String
    If Len(Trim$(HOJAS_EXCLUIDAS)) = 0 Then
        EsHojaExcluida = False
        Exit Function
    End If
    arr = Split(HOJAS_EXCLUIDAS, "|")
    For i = LBound(arr) To UBound(arr)
        item = Trim$(arr(i))
        If Len(item) > 0 Then
            If StrComp(item, nombreHoja, vbTextCompare) = 0 Then
                EsHojaExcluida = True
                Exit Function
            End If
        End If
    Next i
    EsHojaExcluida = False
End Function
