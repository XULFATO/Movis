Attribute VB_Name = "mod_1B_FC_PintarColorCFG"
Option Explicit
Public Sub PintarColorCFG(ByVal celda As Range)
    Dim wsColores As Worksheet
    Dim encontrado As Range
    Dim nombreColor As String
    Dim r As Long, g As Long, b As Long
    Dim brillo As Double
    If celda Is Nothing Then Exit Sub
    nombreColor = Trim$(CStr(celda.Value))
    If nombreColor = "" Then
        celda.Interior.Pattern = xlNone
        celda.Font.Color = RGB(0, 0, 0)
        Exit Sub
    End If
    On Error Resume Next
    Set wsColores = ThisWorkbook.Worksheets("CFG_COLORES")
    On Error GoTo 0
    If wsColores Is Nothing Then Exit Sub
    Set encontrado = wsColores.Range("A:A").Find(nombreColor, LookIn:=xlValues, LookAt:=xlWhole)
    If encontrado Is Nothing Then Exit Sub
    r = CLng(wsColores.Cells(encontrado.Row, "C").Value)
    g = CLng(wsColores.Cells(encontrado.Row, "D").Value)
    b = CLng(wsColores.Cells(encontrado.Row, "E").Value)
    If r < 0 Then
        celda.Interior.Pattern = xlNone
        celda.Font.Color = RGB(0, 0, 0)
        Exit Sub
    End If
    celda.Interior.Color = RGB(r, g, b)
    brillo = (r * 0.299) + (g * 0.587) + (b * 0.114)
    If brillo < 140 Then
        celda.Font.Color = RGB(255, 255, 255)
    Else
        celda.Font.Color = RGB(0, 0, 0)
    End If
End Sub
