Attribute VB_Name = "mod_Esp_BobCel_Main"
Option Explicit
Public Sub GenerarInformeBOB()
    GenerarInformeCliente MARCA_BOB, NOMBRE_BOB
End Sub
Public Sub GenerarInformeCELERGO()
    GenerarInformeCliente MARCA_CELERGO, NOMBRE_CELERGO
End Sub
Private Sub GenerarInformeCliente(ByVal cliente As String, ByVal nombreBase As String)
    Dim rutaFinal As String
    Dim wbNuevo As Workbook
    Dim oldScreenUpdating As Boolean
    Dim oldDisplayAlerts As Boolean
    Dim oldEnableEvents As Boolean
    Dim oldCalculation As XlCalculation
    On Error GoTo ErrHandler
    oldScreenUpdating = Application.ScreenUpdating
    oldDisplayAlerts = Application.DisplayAlerts
    oldEnableEvents = Application.EnableEvents
    oldCalculation = Application.Calculation
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual
    Call AsegurarCarpetas
    If USAR_MOTOR_CFG_POR_CABECERAS Then
        Call GenerarCFGAdaptadasCliente(ThisWorkbook, cliente)
        Call OcultarHojasTecnicasPadre(ThisWorkbook)
    End If
    rutaFinal = SiguienteVersion(nombreBase)
    Set wbNuevo = CrearLibroHijoDesdePadre(ThisWorkbook)
    If QUITAR_ENLACES_EXTERNOS Then
        Call QuitarReferenciasAlPadre(wbNuevo, ThisWorkbook.Name)
    End If
    Call FiltrarFilasPorCliente(wbNuevo, cliente)
    Call FiltrarColumnasPorCliente(wbNuevo, cliente)
    If APLICAR_CFG_ADAPTADAS_EN_HIJO Then
        Call AplicarCFGAdaptadasEnHijo(wbNuevo, cliente)
    End If
    Call BorrarHojasTecnicasHijo(wbNuevo)
    Call AplicarVisibilidadComplementoITHijo(wbNuevo)
    If INSERTAR_MODULOS_PERMITIDOS Then
        Call CopiarModulosPermitidosDesdePadre(ThisWorkbook, wbNuevo) ' Revisado
    End If
    If INSERTAR_EVENTO_BEFORESAVE Then
        Call InsertarEventoThisWorkbookBeforeSave(wbNuevo)
    End If
    wbNuevo.SaveAs Filename:=rutaFinal, FileFormat:=xlOpenXMLWorkbookMacroEnabled
    wbNuevo.Close SaveChanges:=False
    Application.Calculation = oldCalculation
    Application.EnableEvents = oldEnableEvents
    Application.DisplayAlerts = oldDisplayAlerts
    Application.ScreenUpdating = oldScreenUpdating
    MsgBox "Informe generado correctamente:" & vbCrLf & rutaFinal, vbInformation
    Exit Sub
ErrHandler:
    On Error Resume Next
    If Not wbNuevo Is Nothing Then
        wbNuevo.Close SaveChanges:=False
    End If
    Application.Calculation = oldCalculation
    Application.EnableEvents = oldEnableEvents
    Application.DisplayAlerts = oldDisplayAlerts
    Application.ScreenUpdating = oldScreenUpdating
    MsgBox "Error generando informe " & cliente & ":" & vbCrLf & _
           Err.Number & " - " & Err.Description, vbCritical
End Sub
