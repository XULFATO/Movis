Attribute VB_Name = "mod_Esp_BobCel_Freeze"
Option Explicit

Public Sub AplicarVistaInicialHijo(ByVal wb As Workbook)
    ' Punto unico para FreezePanes, zoom y hoja inicial.
    ' Se activa con APLICAR_FREEZE_HIJO = True.
    On Error Resume Next
    If HojaExiste(wb, HOJA_COLUMNAS) Then
        wb.Worksheets(HOJA_COLUMNAS).Activate
        wb.Worksheets(HOJA_COLUMNAS).Range("A" & HOJA_COLUMNAS_FILA_INICIO_DATOS).Select
        ActiveWindow.FreezePanes = False
        ActiveWindow.FreezePanes = True
    End If
    On Error GoTo 0
End Sub
