Attribute VB_Name = "mod_Esp_BobCel_MotorCFG"
Option Explicit

' =====================================================
' MOTOR CFG POR CABECERAS - V3
'
' CAMBIOS IMPORTANTES:
' 1) Si falla la generacion de CFG adaptadas, YA NO continua.
'    Relanza el error para que lo capture el Main.
'
' 2) Desprotege temporalmente la estructura del libro padre antes
'    de borrar/crear hojas CFG_MAPA / CFG_REGLAS_BOB / etc.
'
' 3) Al borrar hojas tecnicas, las hace visibles antes de borrar.
'
' 4) Si hay error, vuelve a proteger la estructura del padre si estaba protegida.
' =====================================================

Public Sub GenerarCFGAdaptadasBOB()

    Call GenerarCFGAdaptadasCliente(ThisWorkbook, MARCA_BOB)

End Sub


Public Sub GenerarCFGAdaptadasCELERGO()

    Call GenerarCFGAdaptadasCliente(ThisWorkbook, MARCA_CELERGO)

End Sub


Public Sub GenerarCFGAdaptadasTodas()

    Call GenerarCFGAdaptadasCliente(ThisWorkbook, MARCA_BOB)
    Call GenerarCFGAdaptadasCliente(ThisWorkbook, MARCA_CELERGO)

    MsgBox "CFG adaptadas generadas para BOB y CELERGO.", vbInformation

End Sub


Public Sub GenerarCFGAdaptadasCliente(ByVal wb As Workbook, ByVal cliente As String)

    Dim wsDatos As Worksheet
    Dim wsMapaBase As Worksheet
    Dim wsMapaCliente As Worksheet

    Dim nombreMapaCliente As String
    Dim nombreReglasCliente As String
    Dim nombreFormulasCliente As String

    Dim estabaProtegidaEstructura As Boolean
    Dim oldAlerts As Boolean
    Dim oldEvents As Boolean

    On Error GoTo ErrHandler

    oldAlerts = Application.DisplayAlerts
    oldEvents = Application.EnableEvents

    Application.DisplayAlerts = False
    Application.EnableEvents = False

    estabaProtegidaEstructura = wb.ProtectStructure

    If estabaProtegidaEstructura Then
        Call DesprotegerLibro(wb)

        If wb.ProtectStructure Then
            Err.Raise vbObjectError + 7001, , _
                "No se puede generar CFG adaptadas porque la estructura del libro padre esta protegida " & _
                "y no se pudo desproteger con PASS_LIBRO."
        End If
    End If

    If Not HojaExiste(wb, HOJA_COLUMNAS) Then
        Err.Raise vbObjectError + 7100, , "No existe la hoja de datos: " & HOJA_COLUMNAS
    End If

    Set wsDatos = wb.Worksheets(HOJA_COLUMNAS)

    Select Case UCase$(Trim$(cliente))

        Case UCase$(MARCA_BOB)
            nombreMapaCliente = HOJA_MAPA_COLUMNAS_BOB
            nombreReglasCliente = HOJA_CFG_REGLAS_BOB
            nombreFormulasCliente = HOJA_CFG_FORMULAS_BOB

        Case UCase$(MARCA_CELERGO)
            nombreMapaCliente = HOJA_MAPA_COLUMNAS_CELERGO
            nombreReglasCliente = HOJA_CFG_REGLAS_CELERGO
            nombreFormulasCliente = HOJA_CFG_FORMULAS_CELERGO

        Case Else
            Err.Raise vbObjectError + 7101, , "Cliente no reconocido: " & cliente

    End Select

    If CFG_ADAPTADAS_BORRAR_ANTES Then
        Call BorrarHojaSiExiste(wb, nombreMapaCliente)
        Call BorrarHojaSiExiste(wb, nombreReglasCliente)
        Call BorrarHojaSiExiste(wb, nombreFormulasCliente)
    End If

    Set wsMapaBase = CrearMapaBaseColumnas(wb, wsDatos)
    Set wsMapaCliente = CrearMapaCliente(wb, wsMapaBase, cliente, nombreMapaCliente)

    Call CrearCFGReglasCliente(wb, wsMapaCliente, nombreReglasCliente)
    Call CrearCFGFormulasCliente(wb, wsMapaCliente, nombreFormulasCliente)

    If Not CFG_MAPAS_VISIBLES Then
        wsMapaCliente.Visible = xlSheetVeryHidden
    End If

Salida:

    On Error Resume Next

    If estabaProtegidaEstructura And PROTEGER_LIBRO_PADRE_AL_FINAL Then
        Call ProtegerLibro(wb)
    End If

    Application.DisplayAlerts = oldAlerts
    Application.EnableEvents = oldEvents

    On Error GoTo 0

    Exit Sub

ErrHandler:

    Dim nErr As Long
    Dim dErr As String

    nErr = Err.Number
    dErr = Err.Description
    If nErr = 0 Then nErr = vbObjectError + 7999
    If Len(dErr) = 0 Then dErr = "Error no especificado dentro de GenerarCFGAdaptadasCliente."

    On Error Resume Next

    If estabaProtegidaEstructura And PROTEGER_LIBRO_PADRE_AL_FINAL Then
        Call ProtegerLibro(wb)
    End If

    Application.DisplayAlerts = oldAlerts
    Application.EnableEvents = oldEvents

    On Error GoTo 0

    Err.Raise nErr, "GenerarCFGAdaptadasCliente", _
        "Error generando CFG adaptadas para " & cliente & ":" & vbCrLf & _
        nErr & " - " & dErr

End Sub


' =====================================================
' MAPA BASE
' =====================================================

Private Function CrearMapaBaseColumnas(ByVal wb As Workbook, ByVal wsDatos As Worksheet) As Worksheet

    Dim wsMapa As Worksheet
    Dim lastCol As Long
    Dim col As Long
    Dim filaOut As Long
    Dim cabeceraVisible As String
    Dim cabeceraNorm As String
    Dim claveMapa As String
    Dim ocurrencias As Object
    Dim n As Long

    Call BorrarHojaSiExiste(wb, HOJA_MAPA_COLUMNAS)

    Set wsMapa = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    wsMapa.Name = HOJA_MAPA_COLUMNAS

    Set ocurrencias = CreateObject("Scripting.Dictionary")

    With wsMapa
        .Range("A1:M1").Value = Array("Activa", "Orden", "Hoja", "Cabecera normalizada", "Cabecera visible", _
                                      "Ocurrencia", "Clave mapa", "Columna padre", "Numero columna padre", _
                                      "Marca cliente", "Usar formulas", "Usar reglas", "Comentario")
        .Rows(1).Font.Bold = True
    End With

    lastCol = UltimaColumnaUsada(wsDatos)
    filaOut = 2

    For col = 1 To lastCol

        cabeceraVisible = TextoCabecera(wsDatos.Cells(HOJA_COLUMNAS_FILA_CABECERA, col))
        cabeceraNorm = NormalizarClaveCabecera(cabeceraVisible)

        If Len(cabeceraNorm) = 0 Then
            cabeceraNorm = "__SIN_CABECERA_" & LetraColumnaLocal(col)
            cabeceraVisible = ""
        End If

        If Not ocurrencias.Exists(cabeceraNorm) Then
            ocurrencias.Add cabeceraNorm, 1
        Else
            ocurrencias(cabeceraNorm) = CLng(ocurrencias(cabeceraNorm)) + 1
        End If

        n = CLng(ocurrencias(cabeceraNorm))

        claveMapa = cabeceraNorm
        If n > 1 Then claveMapa = cabeceraNorm & "#" & CStr(n)

        With wsMapa
            .Cells(filaOut, "A").Value = "SI"
            .Cells(filaOut, "B").Value = filaOut - 1
            .Cells(filaOut, "C").Value = wsDatos.Name
            .Cells(filaOut, "D").Value = cabeceraNorm
            .Cells(filaOut, "E").Value = cabeceraVisible
            .Cells(filaOut, "F").Value = n
            .Cells(filaOut, "G").Value = claveMapa
            .Cells(filaOut, "H").Value = LetraColumnaLocal(col)
            .Cells(filaOut, "I").Value = col
            .Cells(filaOut, "J").Value = CStr(wsDatos.Cells(HOJA_COLUMNAS_FILA_MARCA, col).Value)
            .Cells(filaOut, "K").Value = "SI"
            .Cells(filaOut, "L").Value = "SI"

            If Left$(cabeceraNorm, 14) = "__SIN_CABECERA" Then
                .Cells(filaOut, "M").Value = "Cabecera vacia en fila " & HOJA_COLUMNAS_FILA_CABECERA
            ElseIf n > 1 Then
                .Cells(filaOut, "M").Value = "Cabecera duplicada. Ocurrencia " & n
            Else
                .Cells(filaOut, "M").Value = ""
            End If
        End With

        filaOut = filaOut + 1

    Next col

    wsMapa.Columns.AutoFit

    Set CrearMapaBaseColumnas = wsMapa

End Function


Private Function CrearMapaCliente(ByVal wb As Workbook, ByVal wsMapaBase As Worksheet, ByVal cliente As String, ByVal nombreMapa As String) As Worksheet

    Dim wsOut As Worksheet
    Dim lastRow As Long
    Dim r As Long
    Dim outR As Long
    Dim colActual As Long
    Dim conservar As Boolean
    Dim marca As String

    Call BorrarHojaSiExiste(wb, nombreMapa)

    Set wsOut = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    wsOut.Name = nombreMapa

    With wsOut
        .Range("A1:P1").Value = Array("Activa", "Orden", "Hoja", "Cabecera normalizada", "Cabecera visible", _
                                      "Ocurrencia", "Clave mapa", "Columna padre", "Numero columna padre", _
                                      "Marca cliente", "Columna hijo", "Numero columna hijo", "Existe en hijo", _
                                      "Usar formulas", "Usar reglas", "Comentario")
        .Rows(1).Font.Bold = True
    End With

    lastRow = wsMapaBase.Cells(wsMapaBase.Rows.Count, "A").End(xlUp).Row
    outR = 2
    colActual = 0

    For r = 2 To lastRow

        marca = CStr(wsMapaBase.Cells(r, "J").Value)
        conservar = DebeConservarPorMarca(marca, cliente)

        If conservar Then colActual = colActual + 1

        With wsOut
            .Cells(outR, "A").Value = wsMapaBase.Cells(r, "A").Value
            .Cells(outR, "B").Value = wsMapaBase.Cells(r, "B").Value
            .Cells(outR, "C").Value = wsMapaBase.Cells(r, "C").Value
            .Cells(outR, "D").Value = wsMapaBase.Cells(r, "D").Value
            .Cells(outR, "E").Value = wsMapaBase.Cells(r, "E").Value
            .Cells(outR, "F").Value = wsMapaBase.Cells(r, "F").Value
            .Cells(outR, "G").Value = wsMapaBase.Cells(r, "G").Value
            .Cells(outR, "H").Value = wsMapaBase.Cells(r, "H").Value
            .Cells(outR, "I").Value = wsMapaBase.Cells(r, "I").Value
            .Cells(outR, "J").Value = marca

            If conservar Then
                .Cells(outR, "K").Value = LetraColumnaLocal(colActual)
                .Cells(outR, "L").Value = colActual
                .Cells(outR, "M").Value = "SI"
            Else
                .Cells(outR, "K").Value = ""
                .Cells(outR, "L").Value = ""
                .Cells(outR, "M").Value = "NO"
            End If

            .Cells(outR, "N").Value = wsMapaBase.Cells(r, "K").Value
            .Cells(outR, "O").Value = wsMapaBase.Cells(r, "L").Value
            .Cells(outR, "P").Value = wsMapaBase.Cells(r, "M").Value
        End With

        outR = outR + 1

    Next r

    wsOut.Columns.AutoFit

    Set CrearMapaCliente = wsOut

End Function


' =====================================================
' CFG_REGLAS ADAPTADA
' =====================================================

Private Sub CrearCFGReglasCliente(ByVal wb As Workbook, ByVal wsMapaCliente As Worksheet, ByVal nombreSalida As String)

    Dim wsSrc As Worksheet
    Dim wsOut As Worksheet
    Dim lastRow As Long
    Dim r As Long
    Dim outR As Long
    Dim rangoOrig As String
    Dim formulaOrig As String
    Dim rangoAdap As String
    Dim formulaAdap As String
    Dim estado As String
    Dim motivo As String

    If Not HojaExiste(wb, HOJA_CFG_REGLAS) Then Exit Sub

    Set wsSrc = wb.Worksheets(HOJA_CFG_REGLAS)

    Call BorrarHojaSiExiste(wb, nombreSalida)

    Set wsOut = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    wsOut.Name = nombreSalida

    With wsOut
        .Range("A1:S1").Value = Array("Activa", "Orden", "Nombre regla", _
                                      "Rango aplica original", "Rango aplica adaptado", _
                                      "Formula original", "Formula adaptada", _
                                      "Color fondo", "Color fuente", "Negrita", "StopIfTrue", _
                                      "Tachado", "Borde fino", "Comentario", "Explicacion rango", _
                                      "Explicacion formula", "Resultado aplicar v15", _
                                      "Estado adaptacion", "Motivo")
        .Rows(1).Font.Bold = True
    End With

    lastRow = wsSrc.Cells(wsSrc.Rows.Count, CFG_REGLAS_COL_ACTIVA).End(xlUp).Row
    outR = 2

    For r = CFG_REGLAS_FILA_INICIO To lastRow

        On Error GoTo ErrRegla

        rangoOrig = CStr(wsSrc.Cells(r, CFG_REGLAS_COL_RANGO_APLICA).Value)
        formulaOrig = CStr(wsSrc.Cells(r, CFG_REGLAS_COL_FORMULA).Value)

        estado = "OK"
        motivo = ""

        rangoAdap = AdaptarTextoExcel(rangoOrig, wsMapaCliente, estado, motivo)
        formulaAdap = AdaptarTextoExcel(formulaOrig, wsMapaCliente, estado, motivo)

        If UCase$(Trim$(CStr(wsSrc.Cells(r, CFG_REGLAS_COL_ACTIVA).Value))) <> "SI" Then
            estado = "INACTIVA"
            motivo = "Regla no activa en CFG_REGLAS."
        End If

        With wsOut
            .Cells(outR, "A").Value = wsSrc.Cells(r, CFG_REGLAS_COL_ACTIVA).Value
            .Cells(outR, "B").Value = wsSrc.Cells(r, CFG_REGLAS_COL_ORDEN).Value
            .Cells(outR, "C").Value = wsSrc.Cells(r, CFG_REGLAS_COL_NOMBRE).Value
            Call EscribirTextoSeguro(wsOut, outR, "D", rangoOrig)
            Call EscribirTextoSeguro(wsOut, outR, "E", rangoAdap)
            Call EscribirTextoSeguro(wsOut, outR, "F", formulaOrig)
            Call EscribirTextoSeguro(wsOut, outR, "G", formulaAdap)
            .Cells(outR, "H").Value = wsSrc.Cells(r, CFG_REGLAS_COL_COLOR_FONDO).Value
            .Cells(outR, "I").Value = wsSrc.Cells(r, CFG_REGLAS_COL_COLOR_FUENTE).Value
            .Cells(outR, "J").Value = wsSrc.Cells(r, CFG_REGLAS_COL_NEGRITA).Value
            .Cells(outR, "K").Value = wsSrc.Cells(r, CFG_REGLAS_COL_STOP_IF_TRUE).Value
            .Cells(outR, "L").Value = wsSrc.Cells(r, CFG_REGLAS_COL_TACHADO).Value
            .Cells(outR, "M").Value = wsSrc.Cells(r, CFG_REGLAS_COL_BORDE_FINO).Value
            Call EscribirTextoSeguro(wsOut, outR, "N", wsSrc.Cells(r, CFG_REGLAS_COL_COMENTARIO).Value)
            Call EscribirTextoSeguro(wsOut, outR, "O", wsSrc.Cells(r, CFG_REGLAS_COL_EXPLICA_RANGO).Value)
            Call EscribirTextoSeguro(wsOut, outR, "P", wsSrc.Cells(r, CFG_REGLAS_COL_EXPLICA_FORMULA).Value)
            Call EscribirTextoSeguro(wsOut, outR, "Q", wsSrc.Cells(r, CFG_REGLAS_COL_RESULTADO).Value)
            .Cells(outR, "R").Value = estado
            Call EscribirTextoSeguro(wsOut, outR, "S", motivo)
        End With

        outR = outR + 1

    Next r

    wsOut.Columns.AutoFit

    Exit Sub

ErrRegla:
    Err.Raise Err.Number, "CrearCFGReglasCliente", _
        "Error creando CFG_REGLAS adaptada en fila origen " & r & _
        ", regla [" & CStr(wsSrc.Cells(r, CFG_REGLAS_COL_NOMBRE).Value) & "]." & vbCrLf & _
        "Detalle: " & Err.Description

End Sub


' =====================================================
' CFG_FORMULAS ADAPTADA
' =====================================================

Private Sub CrearCFGFormulasCliente(ByVal wb As Workbook, ByVal wsMapaCliente As Worksheet, ByVal nombreSalida As String)

    Dim wsSrc As Worksheet
    Dim wsOut As Worksheet
    Dim lastRow As Long
    Dim r As Long
    Dim outR As Long
    Dim colOrig As String
    Dim rangoOrig As String
    Dim formulaOrig As String
    Dim colAdap As String
    Dim rangoAdap As String
    Dim formulaAdap As String
    Dim estado As String
    Dim motivo As String

    If Not HojaExiste(wb, HOJA_CFG_FORMULAS) Then Exit Sub

    Set wsSrc = wb.Worksheets(HOJA_CFG_FORMULAS)

    Call BorrarHojaSiExiste(wb, nombreSalida)

    Set wsOut = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    wsOut.Name = nombreSalida

    With wsOut
        .Range("A1:L1").Value = Array("Activa", "Orden", _
                                      "Columna destino original", "Columna destino adaptada", _
                                      "Rango destino original", "Rango destino adaptado", _
                                      "Formula original", "Formula adaptada", _
                                      "Comentario", "Estado adaptacion", "Motivo", "Nota")
        .Rows(1).Font.Bold = True
    End With

    lastRow = wsSrc.Cells(wsSrc.Rows.Count, CFG_FORMULAS_COL_ACTIVA).End(xlUp).Row
    outR = 2

    For r = CFG_FORMULAS_FILA_INICIO To lastRow

        On Error GoTo ErrFormula

        colOrig = CStr(wsSrc.Cells(r, CFG_FORMULAS_COL_COLUMNA_DESTINO).Value)
        rangoOrig = CStr(wsSrc.Cells(r, CFG_FORMULAS_COL_RANGO_DESTINO).Value)
        formulaOrig = CStr(wsSrc.Cells(r, CFG_FORMULAS_COL_FORMULA).Value)

        estado = "OK"
        motivo = ""

        colAdap = LetraActualDesdeLetraPadre(wsMapaCliente, colOrig)
        rangoAdap = AdaptarTextoExcel(rangoOrig, wsMapaCliente, estado, motivo)
        formulaAdap = AdaptarTextoExcel(formulaOrig, wsMapaCliente, estado, motivo)

        If Len(colAdap) = 0 Then
            estado = "DESCARTADA"
            motivo = AgregarMotivo(motivo, "Columna destino eliminada o no encontrada: " & colOrig)
        End If

        If Left$(formulaAdap, 1) = "'" Then formulaAdap = Mid$(formulaAdap, 2)

        If UCase$(Trim$(CStr(wsSrc.Cells(r, CFG_FORMULAS_COL_ACTIVA).Value))) <> "SI" Then
            estado = "INACTIVA"
            motivo = "Formula no activa en CFG_FORMULAS."
        End If

        With wsOut
            .Cells(outR, "A").Value = wsSrc.Cells(r, CFG_FORMULAS_COL_ACTIVA).Value
            .Cells(outR, "B").Value = wsSrc.Cells(r, CFG_FORMULAS_COL_ORDEN).Value
            .Cells(outR, "C").Value = colOrig
            .Cells(outR, "D").Value = colAdap
            Call EscribirTextoSeguro(wsOut, outR, "E", rangoOrig)
            Call EscribirTextoSeguro(wsOut, outR, "F", rangoAdap)
            Call EscribirTextoSeguro(wsOut, outR, "G", formulaOrig)
            Call EscribirTextoSeguro(wsOut, outR, "H", formulaAdap)
            Call EscribirTextoSeguro(wsOut, outR, "I", wsSrc.Cells(r, CFG_FORMULAS_COL_COMENTARIO).Value)
            .Cells(outR, "J").Value = estado
            Call EscribirTextoSeguro(wsOut, outR, "K", motivo)
            .Cells(outR, "L").Value = "Adaptada por mapa de cabeceras fila " & HOJA_COLUMNAS_FILA_CABECERA
        End With

        outR = outR + 1

    Next r

    wsOut.Columns.AutoFit

    Exit Sub

ErrFormula:
    Err.Raise Err.Number, "CrearCFGFormulasCliente", _
        "Error creando CFG_FORMULAS adaptada en fila origen " & r & _
        ", columna destino [" & CStr(wsSrc.Cells(r, CFG_FORMULAS_COL_COLUMNA_DESTINO).Value) & "]." & vbCrLf & _
        "Detalle: " & Err.Description

End Sub


' =====================================================
' ADAPTADOR DE REFERENCIAS
' Traduce letras del padre a letras del hijo segun mapa.
' Protege BASIC! para no tocar columnas de BASIC.
' =====================================================

Private Function AdaptarTextoExcel(ByVal txt As String, ByVal wsMapa As Worksheet, _
                                   ByRef estado As String, ByRef motivo As String) As String

    Dim re As Object
    Dim matches As Object
    Dim m As Object
    Dim i As Long
    Dim s As String
    Dim original As String
    Dim repl As String
    Dim colLetra As String
    Dim rowPart As String

    s = CStr(txt)

    If Len(s) = 0 Then
        AdaptarTextoExcel = s
        Exit Function
    End If

    s = ProtegerReferenciasBasic(s)

    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = False

    ' Captura:
    ' $A5
    ' A5
    ' $A$5
    ' $AA$5:$AA$499 se procesa como dos referencias
    ' $A:$AR se procesa como rango de columnas completas
    re.Pattern = "(\$?)([A-Z]{1,3})(\$?\d+|:\$?[A-Z]{1,3})"

    Set matches = re.Execute(s)

    For i = matches.Count - 1 To 0 Step -1

        Set m = matches(i)

        original = m.Value
        colLetra = UCase$(m.SubMatches(1))
        rowPart = m.SubMatches(2)

        If InStr(1, rowPart, ":", vbTextCompare) > 0 Then
            repl = AdaptarReferenciaColumnaCompleta(original, colLetra, rowPart, wsMapa, estado, motivo)
        Else
            repl = AdaptarReferenciaCelda(original, colLetra, rowPart, wsMapa, estado, motivo)
        End If

        s = Left$(s, m.FirstIndex) & repl & Mid$(s, m.FirstIndex + Len(original) + 1)

    Next i

    s = RestaurarReferenciasBasic(s)

    AdaptarTextoExcel = s

End Function


Private Function AdaptarReferenciaCelda(ByVal original As String, ByVal colLetra As String, ByVal rowPart As String, _
                                        ByVal wsMapa As Worksheet, ByRef estado As String, ByRef motivo As String) As String

    Dim nuevaLetra As String
    Dim absCol As String

    nuevaLetra = LetraActualDesdeLetraPadre(wsMapa, colLetra)

    If Len(nuevaLetra) = 0 Then
        estado = "DESCARTADA"
        motivo = AgregarMotivo(motivo, "Referencia a columna eliminada: " & colLetra)
        AdaptarReferenciaCelda = "#REF!"
        Exit Function
    End If

    If Left$(original, 1) = "$" Then
        absCol = "$"
    Else
        absCol = ""
    End If

    AdaptarReferenciaCelda = absCol & nuevaLetra & rowPart

End Function


Private Function AdaptarReferenciaColumnaCompleta(ByVal original As String, ByVal colLetra As String, ByVal rowPart As String, _
                                                  ByVal wsMapa As Worksheet, ByRef estado As String, ByRef motivo As String) As String

    Dim nueva1 As String
    Dim col2 As String
    Dim nueva2 As String
    Dim p As Long

    nueva1 = LetraActualDesdeLetraPadre(wsMapa, colLetra)

    If Len(nueva1) = 0 Then
        estado = "DESCARTADA"
        motivo = AgregarMotivo(motivo, "Rango usa columna eliminada: " & colLetra)
        AdaptarReferenciaColumnaCompleta = "#REF!"
        Exit Function
    End If

    p = InStr(1, rowPart, ":", vbTextCompare)

    col2 = Replace(Mid$(rowPart, p + 1), "$", "")
    col2 = UCase$(col2)

    nueva2 = LetraActualDesdeLetraPadre(wsMapa, col2)

    If Len(nueva2) = 0 Then
        estado = "DESCARTADA"
        motivo = AgregarMotivo(motivo, "Rango usa columna eliminada: " & col2)
        AdaptarReferenciaColumnaCompleta = "#REF!"
        Exit Function
    End If

    AdaptarReferenciaColumnaCompleta = "$" & nueva1 & ":$" & nueva2

End Function


Private Function ProtegerReferenciasBasic(ByVal s As String) As String

    Dim re As Object
    Dim matches As Object
    Dim m As Object
    Dim i As Long
    Dim t As String

    t = s

    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "BASIC!\$?[A-Z]{1,3}(:\$?[A-Z]{1,3}|\$?\d+)?"

    Set matches = re.Execute(t)

    For i = matches.Count - 1 To 0 Step -1
        Set m = matches(i)
        t = Left$(t, m.FirstIndex) & _
            Replace(Replace(m.Value, "$", "�DOL�"), ":", "�COL�") & _
            Mid$(t, m.FirstIndex + Len(m.Value) + 1)
    Next i

    ProtegerReferenciasBasic = t

End Function


Private Function RestaurarReferenciasBasic(ByVal s As String) As String

    s = Replace(s, "�DOL�", "$")
    s = Replace(s, "�COL�", ":")

    RestaurarReferenciasBasic = s

End Function


' =====================================================
' BUSQUEDA EN MAPA
' =====================================================

Private Function LetraActualDesdeLetraPadre(ByVal wsMapa As Worksheet, ByVal letraPadre As String) As String

    Dim lastRow As Long
    Dim r As Long

    letraPadre = UCase$(Replace(Trim$(letraPadre), "$", ""))

    If Len(letraPadre) = 0 Then Exit Function

    lastRow = wsMapa.Cells(wsMapa.Rows.Count, "A").End(xlUp).Row

    For r = 2 To lastRow
        If UCase$(Trim$(CStr(wsMapa.Cells(r, "H").Value))) = letraPadre Then
            If UCase$(Trim$(CStr(wsMapa.Cells(r, "M").Value))) = "SI" Then
                LetraActualDesdeLetraPadre = CStr(wsMapa.Cells(r, "K").Value)
            Else
                LetraActualDesdeLetraPadre = vbNullString
            End If
            Exit Function
        End If
    Next r

End Function



Private Sub EscribirTextoSeguro(ByVal ws As Worksheet, ByVal fila As Long, ByVal col As Variant, ByVal valor As Variant)

    With ws.Cells(fila, col)
        .NumberFormat = "@"
        .Value2 = CStr(valor)
    End With

End Sub


' =====================================================
' UTILIDADES LOCALES
' =====================================================

Private Sub BorrarHojaSiExiste(ByVal wb As Workbook, ByVal nombreHoja As String)

    Dim ws As Worksheet
    Dim oldAlerts As Boolean

    If Not HojaExiste(wb, nombreHoja) Then Exit Sub
    If wb.Worksheets.Count <= 1 Then Exit Sub

    oldAlerts = Application.DisplayAlerts
    Application.DisplayAlerts = False

    Set ws = wb.Worksheets(nombreHoja)
    ws.Visible = xlSheetVisible
    ws.Delete

    Application.DisplayAlerts = oldAlerts

End Sub


Private Function TextoCabecera(ByVal celda As Range) As String

    Dim v As String

    If celda.MergeCells Then
        v = CStr(celda.MergeArea.Cells(1, 1).Value)
    Else
        v = CStr(celda.Value)
    End If

    v = Replace(v, vbCr, " ")
    v = Replace(v, vbLf, " ")
    v = Replace(v, ChrW$(160), " ")
    v = Application.WorksheetFunction.Trim(v)

    TextoCabecera = v

End Function


Private Function NormalizarClaveCabecera(ByVal s As String) As String

    s = UCase$(Trim$(s))
    s = Replace(s, vbCr, " ")
    s = Replace(s, vbLf, " ")
    s = Replace(s, ChrW$(160), " ")
    s = Application.WorksheetFunction.Trim(s)

    s = Replace(s, "�", "A")
    s = Replace(s, "�", "E")
    s = Replace(s, "�", "I")
    s = Replace(s, "�", "O")
    s = Replace(s, "�", "U")
    s = Replace(s, "�", "U")
    s = Replace(s, "�", "N")

    NormalizarClaveCabecera = s

End Function


Private Function LetraColumnaLocal(ByVal numeroColumna As Long) As String

    LetraColumnaLocal = Split(Cells(1, numeroColumna).Address(False, False), "1")(0)

End Function


Private Function AgregarMotivo(ByVal motivoActual As String, ByVal nuevoMotivo As String) As String

    If Len(motivoActual) = 0 Then
        AgregarMotivo = nuevoMotivo
    Else
        AgregarMotivo = motivoActual & " | " & nuevoMotivo
    End If

End Function
