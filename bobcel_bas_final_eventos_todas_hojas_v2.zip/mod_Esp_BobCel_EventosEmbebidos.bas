Attribute VB_Name = "mod_Esp_BobCel_EventosEmbebidos"
Option Explicit

' =====================================================
' EVENTOS EMBEBIDOS / COPIA DE CODIGO DOCUMENTAL
'
' Este modulo gestiona codigo que vive en:
' - ThisWorkbook
' - Modulos de hoja
'
' IMPORTANTE:
' Los modulos de hoja NO son modulos .bas normales.
' Son componentes documentales. Por eso no entran en MODULOS_CONSERVAR.
' =====================================================


Public Sub InsertarEventoThisWorkbookBeforeSave(ByVal wb As Workbook)

    Dim comp As Object
    Dim cm As Object
    Dim codigo As String

    If Not PuedeAccederVBProjectEventos(wb) Then
        Err.Raise vbObjectError + 2400, , _
            "No se puede acceder al VBProject del libro hijo para insertar evento ThisWorkbook."
    End If

    Set comp = wb.VBProject.VBComponents("ThisWorkbook")
    Set cm = comp.CodeModule

    codigo = _
        "Private Sub Workbook_BeforeSave(ByVal SaveAsUI As Boolean, Cancel As Boolean)" & vbCrLf & _
        "    Cancel = True" & vbCrLf & _
        "    Call Mod_GuardarArchivo.GuardarArchivo" & vbCrLf & _
        "End Sub"

    Call ReemplazarProcedimientoSiExiste(cm, "Workbook_BeforeSave")
    cm.AddFromString codigo

End Sub


' =====================================================
' COPIA TODOS LOS EVENTOS DE TODAS LAS HOJAS
' =====================================================
' Copia el codigo real de cada modulo de hoja del padre al hijo,
' siempre que exista una hoja con el mismo nombre en ambos libros.
'
' Esto copia:
' - Worksheet_Change
' - Worksheet_SelectionChange
' - Worksheet_BeforeDoubleClick
' - cualquier otro evento de hoja
'
' No inventa codigo.
' No copia desde texto incrustado.
' No toca ThisWorkbook.
' =====================================================

Public Sub CopiarCodigoHojasConEventosDesdePadre(ByVal wbPadre As Workbook, ByVal wbHijo As Workbook)

    Dim wsPadre As Worksheet
    Dim totalCopiadas As Long

    If Not PuedeAccederVBProjectEventos(wbPadre) Then
        Err.Raise vbObjectError + 9400, , _
            "No se puede acceder al VBProject del libro padre para copiar eventos de hojas."
    End If

    If Not PuedeAccederVBProjectEventos(wbHijo) Then
        Err.Raise vbObjectError + 9401, , _
            "No se puede acceder al VBProject del libro hijo para copiar eventos de hojas."
    End If

    For Each wsPadre In wbPadre.Worksheets

        If HojaExiste(wbHijo, wsPadre.Name) Then
            On Error GoTo ErrHoja

            If CopiarCodigoModuloHojaPorNombre(wbPadre, wbHijo, wsPadre.Name) Then
                totalCopiadas = totalCopiadas + 1
            End If

            On Error GoTo 0
        End If

    Next wsPadre

    Exit Sub

ErrHoja:
    Err.Raise Err.Number, "CopiarCodigoHojasConEventosDesdePadre", _
        "Error copiando eventos de la hoja [" & wsPadre.Name & "]." & vbCrLf & _
        Err.Description

End Sub


Private Function CopiarCodigoModuloHojaPorNombre(ByVal wbPadre As Workbook, _
                                                 ByVal wbHijo As Workbook, _
                                                 ByVal nombreHoja As String) As Boolean

    Dim wsPadre As Worksheet
    Dim wsHijo As Worksheet
    Dim compPadre As Object
    Dim compHijo As Object
    Dim cmPadre As Object
    Dim cmHijo As Object
    Dim textoCodigo As String

    If Not HojaExiste(wbPadre, nombreHoja) Then Exit Function
    If Not HojaExiste(wbHijo, nombreHoja) Then Exit Function

    Set wsPadre = wbPadre.Worksheets(nombreHoja)
    Set wsHijo = wbHijo.Worksheets(nombreHoja)

    Set compPadre = wbPadre.VBProject.VBComponents(wsPadre.CodeName)
    Set compHijo = wbHijo.VBProject.VBComponents(wsHijo.CodeName)

    Set cmPadre = compPadre.CodeModule
    Set cmHijo = compHijo.CodeModule

    If cmPadre.CountOfLines = 0 Then Exit Function

    textoCodigo = cmPadre.Lines(1, cmPadre.CountOfLines)

    If Len(Trim$(textoCodigo)) = 0 Then Exit Function

    If cmHijo.CountOfLines > 0 Then
        cmHijo.DeleteLines 1, cmHijo.CountOfLines
    End If

    cmHijo.AddFromString textoCodigo

    CopiarCodigoModuloHojaPorNombre = True

End Function


Private Sub ReemplazarProcedimientoSiExiste(ByVal cm As Object, ByVal nombreProc As String)

    Dim lineaInicio As Long
    Dim lineasProc As Long

    On Error Resume Next

    lineaInicio = cm.ProcStartLine(nombreProc, 0)
    lineasProc = cm.ProcCountLines(nombreProc, 0)

    If lineaInicio > 0 And lineasProc > 0 Then
        cm.DeleteLines lineaInicio, lineasProc
    End If

    On Error GoTo 0

End Sub


Private Function PuedeAccederVBProjectEventos(ByVal wb As Workbook) As Boolean

    Dim n As Long

    On Error GoTo ErrHandler
    n = wb.VBProject.VBComponents.Count
    PuedeAccederVBProjectEventos = True
    Exit Function

ErrHandler:
    PuedeAccederVBProjectEventos = False

End Function
