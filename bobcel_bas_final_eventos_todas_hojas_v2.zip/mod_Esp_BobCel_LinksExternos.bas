Attribute VB_Name = "mod_Esp_BobCel_LinksExternos"
Option Explicit

Public Sub QuitarReferenciasAlPadre(ByVal wb As Workbook, ByVal nombrePadre As String)

    Dim ws As Worksheet
    Dim rng As Range
    Dim c As Range
    Dim f As String
    Dim patron As String
    Dim estabaProtegida As Boolean

    patron = "[" & nombrePadre & "]"

    For Each ws In wb.Worksheets

        estabaProtegida = ws.ProtectContents

        If estabaProtegida Then
            Call DesprotegerHoja(ws)
            If ws.ProtectContents Then
                Err.Raise vbObjectError + 4500, , _
                    "No se pudo desproteger la hoja para quitar referencias al padre: " & ws.Name
            End If
        End If

        Set rng = Nothing

        On Error Resume Next
        Set rng = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
        On Error GoTo 0

        If Not rng Is Nothing Then

            For Each c In rng.Cells

                f = c.FormulaLocal

                If InStr(1, f, patron, vbTextCompare) > 0 Then
                    f = Replace(f, patron, vbNullString, 1, -1, vbTextCompare)
                    c.FormulaLocal = f
                End If

            Next c

        End If

        If estabaProtegida Then Call ProtegerHoja(ws)

    Next ws

End Sub
