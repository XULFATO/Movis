Attribute VB_Name = "mod_Esp_BobCel_Utilidades"
Option Explicit

Public Function NormalizarTexto(ByVal valor As Variant) As String
    Dim s As String
    If IsError(valor) Then NormalizarTexto = "": Exit Function
    s = CStr(valor)
    s = Replace(s, ChrW$(160), " ")
    s = Trim$(s)
    NormalizarTexto = s
End Function

Public Function NormalizarMarca(ByVal valor As Variant) As String
    NormalizarMarca = UCase$(NormalizarTexto(valor))
End Function

Public Function DebeConservarPorMarca(ByVal marca As Variant, ByVal cliente As String) As Boolean
    Dim m As String, c As String
    m = NormalizarMarca(marca)
    c = NormalizarMarca(cliente)
    Select Case m
        Case "": DebeConservarPorMarca = True
        Case NormalizarMarca(MARCA_AMBOS): DebeConservarPorMarca = True
        Case NormalizarMarca(MARCA_BOB): DebeConservarPorMarca = (c = NormalizarMarca(MARCA_BOB))
        Case NormalizarMarca(MARCA_CELERGO): DebeConservarPorMarca = (c = NormalizarMarca(MARCA_CELERGO))
        Case Else: DebeConservarPorMarca = True
    End Select
End Function

Public Function HojaExiste(ByVal wb As Workbook, ByVal nombreHoja As String) As Boolean
    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets(nombreHoja)
    On Error GoTo 0
    HojaExiste = Not ws Is Nothing
End Function

Public Function UltimaFilaUsada(ByVal ws As Worksheet) As Long
    Dim c As Range
    On Error Resume Next
    Set c = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If c Is Nothing Then UltimaFilaUsada = 1 Else UltimaFilaUsada = c.Row
End Function

Public Function UltimaColumnaUsada(ByVal ws As Worksheet) As Long
    Dim c As Range
    On Error Resume Next
    Set c = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If c Is Nothing Then UltimaColumnaUsada = 1 Else UltimaColumnaUsada = c.Column
End Function

Public Function LetraColumna(ByVal numeroColumna As Long) As String
    LetraColumna = Split(Cells(1, numeroColumna).Address(False, False), "1")(0)
End Function

Public Function EsSi(ByVal valor As Variant) As Boolean
    Dim s As String
    s = UCase$(Trim$(CStr(valor)))
    s = Replace(s, "�", "I")
    EsSi = (s = "SI" Or s = "S" Or s = "TRUE" Or s = "VERDADERO")
End Function

Public Function PuedeAccederVBProject(ByVal wb As Workbook) As Boolean
    Dim n As Long
    On Error GoTo ErrHandler
    n = wb.VBProject.VBComponents.Count
    PuedeAccederVBProject = True
    Exit Function
ErrHandler:
    PuedeAccederVBProject = False
End Function

Public Sub AplicarVisibilidadComplementoITHijo(ByVal wb As Workbook)
    Dim wsPreg As Worksheet, wsIT As Worksheet, valor As String
    On Error Resume Next
    Set wsPreg = wb.Worksheets(HOJA_FILAS)
    Set wsIT = wb.Worksheets(HOJA_COMPLEMENTO_IT)
    On Error GoTo 0
    If wsPreg Is Nothing Or wsIT Is Nothing Then Exit Sub
    valor = UCase$(Trim$(CStr(wsPreg.Range(HOJA_FILAS_CELDA_COMPLEMENTO_IT).Value)))
    valor = Replace(valor, "�", "I")
    If valor = "SI" Then
        wsIT.Visible = xlSheetVisible
    Else
        If wb.Worksheets.Count > 1 Then wsIT.Visible = xlSheetVeryHidden
    End If
End Sub
