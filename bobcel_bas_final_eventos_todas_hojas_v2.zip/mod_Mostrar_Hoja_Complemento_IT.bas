Attribute VB_Name = "mod_Mostrar_Hoja_Complemento_IT"
Option Explicit

Public Sub ActualizarVisibilidadComplementoIT()

    Dim wsControl As Worksheet
    Dim wsComplemento As Worksheet
    Dim valor As String

    On Error GoTo ErrHandler

    Set wsControl = ThisWorkbook.Worksheets("Preg Generales - Propuesta 2")
    Set wsComplemento = ThisWorkbook.Worksheets("Complemento IT")

    valor = UCase$(Trim$(CStr(wsControl.Range("C25").Value)))
    valor = Replace(valor, "�", "I")

    If valor = "SI" Then
        wsComplemento.Visible = xlSheetVisible
    Else
        If ThisWorkbook.Worksheets.Count > 1 Then
            wsComplemento.Visible = xlSheetVeryHidden
        End If
    End If

    Exit Sub

ErrHandler:
    MsgBox "Error actualizando Complemento IT:" & vbCrLf & _
           Err.Number & " - " & Err.Description, vbExclamation

End Sub
