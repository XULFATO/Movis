Attribute VB_Name = "mod_Esp_BobCel_LimpiezaHijo"
Option Explicit

' =====================================================
' LIMPIEZA / OCULTACION DE HOJAS TECNICAS
'
' PADRE:
'   Oculta en VeryHidden las hojas definidas en:
'   HOJAS_TECNICAS_PADRE_OCULTAR
'
' HIJO:
'   Borra definitivamente las hojas definidas en:
'   HOJAS_TECNICAS_HIJO_BORRAR
'
' NOTA:
'   No se borra BASIC salvo que lo pongas expresamente en Config.
' =====================================================

Public Sub OcultarHojasTecnicasPadre(ByVal wb As Workbook)

    Dim arr() As String
    Dim i As Long
    Dim nombreHoja As String
    Dim estructuraProtegida As Boolean

    estructuraProtegida = wb.ProtectStructure

    If estructuraProtegida Then
        Call DesprotegerLibro(wb)

        If wb.ProtectStructure Then
            Err.Raise vbObjectError + 9300, , _
                "No se pudo desproteger la estructura del libro padre para ocultar hojas tecnicas."
        End If
    End If

    arr = Split(HOJAS_TECNICAS_PADRE_OCULTAR, "|")

    For i = LBound(arr) To UBound(arr)

        nombreHoja = Trim$(CStr(arr(i)))

        If Len(nombreHoja) > 0 Then
            If HojaExiste(wb, nombreHoja) Then
                If wb.Worksheets.Count > 1 Then
                    wb.Worksheets(nombreHoja).Visible = xlSheetVeryHidden
                End If
            End If
        End If

    Next i

    If estructuraProtegida Then Call ProtegerLibro(wb)

End Sub


Public Sub BorrarHojasTecnicasHijo(ByVal wb As Workbook)

    Dim arr() As String
    Dim i As Long
    Dim nombreHoja As String
    Dim estructuraProtegida As Boolean
    Dim oldAlerts As Boolean

    estructuraProtegida = wb.ProtectStructure

    If estructuraProtegida Then
        Call DesprotegerLibro(wb)

        If wb.ProtectStructure Then
            Err.Raise vbObjectError + 9310, , _
                "No se pudo desproteger la estructura del libro hijo para borrar hojas tecnicas."
        End If
    End If

    oldAlerts = Application.DisplayAlerts
    Application.DisplayAlerts = False

    arr = Split(HOJAS_TECNICAS_HIJO_BORRAR, "|")

    For i = LBound(arr) To UBound(arr)

        nombreHoja = Trim$(CStr(arr(i)))

        If Len(nombreHoja) > 0 Then
            Call BorrarHojaTecnicaSiExiste(wb, nombreHoja)
        End If

    Next i

    Application.DisplayAlerts = oldAlerts

    If estructuraProtegida Then Call ProtegerLibro(wb)

End Sub


Private Sub BorrarHojaTecnicaSiExiste(ByVal wb As Workbook, ByVal nombreHoja As String)

    Dim ws As Worksheet

    If Not HojaExiste(wb, nombreHoja) Then Exit Sub

    If wb.Worksheets.Count <= 1 Then
        Err.Raise vbObjectError + 9320, , _
            "No se puede borrar la hoja tecnica porque es la ultima hoja del libro: " & nombreHoja
    End If

    Set ws = wb.Worksheets(nombreHoja)

    ws.Visible = xlSheetVisible
    ws.Delete

End Sub
