Attribute VB_Name = "mod_Esp_BobCel_Diagnostico"
Option Explicit

Public Sub CrearInventarioBobCel()
    Dim ws As Worksheet, f As Long
    Application.DisplayAlerts = False
    If HojaExiste(ThisWorkbook, "INVENTARIO_BOBCEL") Then ThisWorkbook.Worksheets("INVENTARIO_BOBCEL").Delete
    Application.DisplayAlerts = True
    Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
    ws.Name = "INVENTARIO_BOBCEL"
    ws.Range("A1:C1").Value = Array("Bloque", "Clave", "Valor")
    ws.Rows(1).Font.Bold = True
    f = 2
    EscribirInv ws, f, "Hojas", "HOJA_COLUMNAS", HOJA_COLUMNAS
    EscribirInv ws, f, "Hojas", "HOJA_FILAS", HOJA_FILAS
    EscribirInv ws, f, "Hojas", "HOJA_BASIC", HOJA_BASIC
    EscribirInv ws, f, "Hojas", "HOJAS_EXCLUIDAS", HOJAS_EXCLUIDAS
    EscribirInv ws, f, "Tecnicas", "PADRE_OCULTAR", HOJAS_TECNICAS_PADRE_OCULTAR
    EscribirInv ws, f, "Tecnicas", "HIJO_BORRAR", HOJAS_TECNICAS_HIJO_BORRAR
    EscribirInv ws, f, "Modulos", "MODULOS_CONSERVAR", MODULOS_CONSERVAR
    EscribirInv ws, f, "Flags", "USAR_MOTOR_CFG_POR_CABECERAS", CStr(USAR_MOTOR_CFG_POR_CABECERAS)
    EscribirInv ws, f, "Flags", "APLICAR_CFG_ADAPTADAS_EN_HIJO", CStr(APLICAR_CFG_ADAPTADAS_EN_HIJO)
    ws.Columns.AutoFit
End Sub

Private Sub EscribirInv(ByVal ws As Worksheet, ByRef f As Long, ByVal bloque As String, ByVal clave As String, ByVal valor As String)
    ws.Cells(f, "A").Value = bloque
    ws.Cells(f, "B").Value = clave
    ws.Cells(f, "C").Value = valor
    f = f + 1
End Sub
