Attribute VB_Name = "mod_Esp_BobCel_AplicarCFG_Hijo"
Option Explicit

' =====================================================
' APLICA CFG ADAPTADAS EN EL HIJO
'
' V4:
' - Si una formula adaptada contiene #REF, intenta limpiarla quitando
'   solo los bloques SI(...) que contienen esa referencia rota.
' - Esto evita que AVISO quede vacio cuando una parte de la formula
'   depende de una columna eliminada.
' - Aplica por Rango destino adaptado y, si falta, reconstruye el rango
'   usando Columna destino adaptada.
' - Limpia formulas rotas antes y despues.
' =====================================================

Public Sub AplicarCFGAdaptadasEnHijo(ByVal wb As Workbook, ByVal cliente As String)

    Dim hojaFormulas As String
    Dim hojaReglas As String
    Dim formulasAplicadas As Long

    Select Case UCase$(Trim$(cliente))

        Case UCase$(MARCA_BOB)
            hojaFormulas = HOJA_CFG_FORMULAS_BOB
            hojaReglas = HOJA_CFG_REGLAS_BOB

        Case UCase$(MARCA_CELERGO)
            hojaFormulas = HOJA_CFG_FORMULAS_CELERGO
            hojaReglas = HOJA_CFG_REGLAS_CELERGO

        Case Else
            Err.Raise vbObjectError + 8100, , _
                "Cliente no reconocido al aplicar CFG adaptadas: " & cliente

    End Select

    Call LimpiarFormulasRotasAnalisis(wb)

    If HojaExiste(wb, hojaFormulas) Then
        formulasAplicadas = AplicarFormulasAdaptadas(wb, hojaFormulas)
    Else
        Err.Raise vbObjectError + 8101, , _
            "No existe la hoja de formulas adaptadas en el hijo: " & hojaFormulas
    End If

    If formulasAplicadas = 0 Then
        Err.Raise vbObjectError + 8102, , _
            "No se aplico ninguna formula adaptada desde " & hojaFormulas & "." & vbCrLf & _
            "Revisa Estado adaptacion / Motivo / Formula adaptada."
    End If

    If HojaExiste(wb, hojaReglas) Then
        Call AplicarReglasAdaptadas(wb, hojaReglas)
    Else
        Err.Raise vbObjectError + 8103, , _
            "No existe la hoja de reglas adaptadas en el hijo: " & hojaReglas
    End If

    Call LimpiarFormulasRotasAnalisis(wb)

    If CFG_OCULTAR_TECNICAS_EN_HIJO Then
        Call OcultarHojasTecnicasCFG(wb)
    End If

End Sub


Private Sub LimpiarFormulasRotasAnalisis(ByVal wb As Workbook)

    Dim ws As Worksheet
    Dim rng As Range
    Dim c As Range
    Dim f As String
    Dim estabaProtegida As Boolean

    If Not HojaExiste(wb, HOJA_COLUMNAS) Then Exit Sub

    Set ws = wb.Worksheets(HOJA_COLUMNAS)

    estabaProtegida = ws.ProtectContents

    If estabaProtegida Then
        Call DesprotegerHoja(ws)
        If ws.ProtectContents Then
            Err.Raise vbObjectError + 8190, , _
                "No se pudo desproteger " & HOJA_COLUMNAS & " para limpiar formulas rotas."
        End If
    End If

    Set rng = Nothing

    On Error Resume Next
    Set rng = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
    On Error GoTo 0

    If Not rng Is Nothing Then
        For Each c In rng.Cells
            f = c.FormulaLocal

            If TieneRefRota(f) Then
                c.ClearContents
            End If
        Next c
    End If

    If estabaProtegida Then Call ProtegerHoja(ws)

End Sub


Private Function AplicarFormulasAdaptadas(ByVal wb As Workbook, ByVal nombreHojaCFG As String) As Long

    Dim wsCFG As Worksheet
    Dim wsDatos As Worksheet
    Dim lastRow As Long
    Dim r As Long
    Dim activa As String
    Dim estado As String
    Dim colDestinoAdaptada As String
    Dim rangoOriginal As String
    Dim rangoAdaptado As String
    Dim formulaTxt As String
    Dim formulaLimpia As String
    Dim rngOriginal As Range
    Dim rngAdaptado As Range
    Dim estabaProtegida As Boolean
    Dim contador As Long

    Set wsCFG = wb.Worksheets(nombreHojaCFG)

    If Not HojaExiste(wb, HOJA_COLUMNAS) Then
        Err.Raise vbObjectError + 8200, , _
            "No existe hoja destino de datos: " & HOJA_COLUMNAS
    End If

    Set wsDatos = wb.Worksheets(HOJA_COLUMNAS)

    estabaProtegida = wsDatos.ProtectContents

    If estabaProtegida Then
        Call DesprotegerHoja(wsDatos)
        If wsDatos.ProtectContents Then
            Err.Raise vbObjectError + 8201, , _
                "No se pudo desproteger: " & HOJA_COLUMNAS
        End If
    End If

    lastRow = wsCFG.Cells(wsCFG.Rows.Count, "A").End(xlUp).Row

    For r = 2 To lastRow

        activa = UCase$(Trim$(CStr(wsCFG.Cells(r, "A").Value)))
        estado = UCase$(Trim$(CStr(wsCFG.Cells(r, "J").Value)))

        colDestinoAdaptada = Trim$(CStr(wsCFG.Cells(r, "D").Value))
        rangoOriginal = CStr(wsCFG.Cells(r, "E").Value)
        rangoAdaptado = CStr(wsCFG.Cells(r, "F").Value)
        formulaTxt = CStr(wsCFG.Cells(r, "H").Value)

        If Left$(formulaTxt, 1) = "'" Then formulaTxt = Mid$(formulaTxt, 2)

        ' Limpia el rango original porque ahi puede quedar la formula vieja rota.
        Set rngOriginal = Nothing
        If Len(Trim$(rangoOriginal)) > 0 And Not TieneRefRota(rangoOriginal) Then
            On Error Resume Next
            Set rngOriginal = wsDatos.Range(rangoOriginal)
            On Error GoTo 0

            If Not rngOriginal Is Nothing Then rngOriginal.ClearContents
        End If

        ' Si no tenemos rango adaptado pero si columna adaptada, lo reconstruimos.
        If (Len(Trim$(rangoAdaptado)) = 0 Or TieneRefRota(rangoAdaptado)) And Len(colDestinoAdaptada) > 0 Then
            rangoAdaptado = "$" & colDestinoAdaptada & "$" & CStr(HOJA_COLUMNAS_FILA_INICIO_DATOS) & _
                           ":$" & colDestinoAdaptada & "$499"
            wsCFG.Cells(r, "F").NumberFormat = "@"
            wsCFG.Cells(r, "F").Value2 = rangoAdaptado
        End If

        Set rngAdaptado = Nothing

        If Len(Trim$(rangoAdaptado)) > 0 And Not TieneRefRota(rangoAdaptado) Then

            On Error Resume Next
            Set rngAdaptado = wsDatos.Range(rangoAdaptado)
            On Error GoTo 0

            If Not rngAdaptado Is Nothing Then

                rngAdaptado.ClearContents

                If activa = "SI" Then

                    formulaLimpia = formulaTxt

                    If TieneRefRota(formulaLimpia) Then
                        formulaLimpia = LimpiarFormulaQuitandoBloquesRef(formulaLimpia)
                    End If

                    If Len(Trim$(formulaLimpia)) > 0 And Not TieneRefRota(formulaLimpia) Then

                        On Error GoTo ErrorFormula
                        rngAdaptado.FormulaLocal = formulaLimpia
                        On Error GoTo 0

                        wsCFG.Cells(r, "J").Value = "OK"
                        If formulaLimpia <> formulaTxt Then
                            wsCFG.Cells(r, "K").Value = "Formula aplicada limpiando bloques con #REF."
                            wsCFG.Cells(r, "H").NumberFormat = "@"
                            wsCFG.Cells(r, "H").Value2 = formulaLimpia
                        End If

                        contador = contador + 1

                    Else
                        wsCFG.Cells(r, "J").Value = "DESCARTADA"
                        wsCFG.Cells(r, "K").Value = "Formula adaptada contiene #REF y no se pudo limpiar."
                    End If

                End If

            Else
                wsCFG.Cells(r, "J").Value = "ERROR"
                wsCFG.Cells(r, "K").Value = "No se pudo resolver rango destino adaptado: " & rangoAdaptado
            End If

        Else
            wsCFG.Cells(r, "J").Value = "ERROR"
            wsCFG.Cells(r, "K").Value = "Rango destino adaptado vacio o con #REF: " & rangoAdaptado
        End If

SiguienteFormula:
    Next r

    If estabaProtegida Then Call ProtegerHoja(wsDatos)

    AplicarFormulasAdaptadas = contador
    Exit Function

ErrorFormula:

    wsCFG.Cells(r, "J").Value = "ERROR"
    wsCFG.Cells(r, "K").Value = "Excel no acepto la formula adaptada. " & _
                                "Rango=" & rangoAdaptado & ". Error: " & Err.Description

    Err.Clear
    On Error GoTo 0
    Resume SiguienteFormula

End Function


' =====================================================
' LIMPIEZA DE FORMULAS CON #REF
' Quita funciones SI(...) completas que contengan #REF / #�REF.
' Trabaja de derecha a izquierda para quitar primero bloques internos.
' =====================================================

Private Function LimpiarFormulaQuitandoBloquesRef(ByVal formulaTxt As String) As String

    Dim s As String
    Dim i As Long
    Dim ini As Long
    Dim fin As Long
    Dim bloque As String
    Dim cambio As Boolean
    Dim vueltas As Long

    s = formulaTxt

    Do
        cambio = False
        vueltas = vueltas + 1

        For i = Len(s) - 2 To 1 Step -1

            If UCase$(Mid$(s, i, 3)) = "SI(" Then

                ini = i
                fin = PosicionParentesisCierre(s, ini + 2)

                If fin > ini Then

                    bloque = Mid$(s, ini, fin - ini + 1)

                    If TieneRefRota(bloque) Then

                        ' No quitamos el SI exterior de toda la formula.
                        If ini > 2 Then
                            s = Left$(s, ini - 1) & """""" & Mid$(s, fin + 1)
                            cambio = True
                            Exit For
                        End If

                    End If

                End If

            End If

        Next i

        If vueltas > 200 Then Exit Do

    Loop While cambio And TieneRefRota(s)

    LimpiarFormulaQuitandoBloquesRef = s

End Function


Private Function PosicionParentesisCierre(ByVal s As String, ByVal posParentesisApertura As Long) As Long

    Dim i As Long
    Dim nivel As Long
    Dim ch As String
    Dim dentroTexto As Boolean

    For i = posParentesisApertura To Len(s)

        ch = Mid$(s, i, 1)

        If ch = """" Then
            If i < Len(s) And Mid$(s, i + 1, 1) = """" Then
                i = i + 1
            Else
                dentroTexto = Not dentroTexto
            End If

        ElseIf Not dentroTexto Then

            If ch = "(" Then
                nivel = nivel + 1
            ElseIf ch = ")" Then
                nivel = nivel - 1
                If nivel = 0 Then
                    PosicionParentesisCierre = i
                    Exit Function
                End If
            End If

        End If

    Next i

End Function


Private Function TieneRefRota(ByVal s As String) As Boolean

    TieneRefRota = (InStr(1, s, "#REF", vbTextCompare) > 0 Or _
                    InStr(1, s, "#�REF", vbTextCompare) > 0 Or _
                    InStr(1, s, "#�REF", vbTextCompare) > 0)

End Function


Private Sub AplicarReglasAdaptadas(ByVal wb As Workbook, ByVal nombreHojaCFG As String)

    Dim wsCFG As Worksheet
    Dim wsDatos As Worksheet
    Dim lastRow As Long
    Dim r As Long
    Dim activa As String
    Dim estado As String
    Dim rangoAplica As String
    Dim formulaTxt As String
    Dim formulaLimpia As String
    Dim rng As Range
    Dim fc As FormatCondition
    Dim estabaProtegida As Boolean

    Set wsCFG = wb.Worksheets(nombreHojaCFG)

    If Not HojaExiste(wb, HOJA_COLUMNAS) Then
        Err.Raise vbObjectError + 8300, , _
            "No existe hoja destino de datos: " & HOJA_COLUMNAS
    End If

    Set wsDatos = wb.Worksheets(HOJA_COLUMNAS)

    estabaProtegida = wsDatos.ProtectContents

    If estabaProtegida Then
        Call DesprotegerHoja(wsDatos)
        If wsDatos.ProtectContents Then
            Err.Raise vbObjectError + 8301, , _
                "No se pudo desproteger: " & HOJA_COLUMNAS
        End If
    End If

    If CFG_APLICAR_BORRAR_FC_PREVIAS Then
        wsDatos.Cells.FormatConditions.Delete
    End If

    lastRow = wsCFG.Cells(wsCFG.Rows.Count, "A").End(xlUp).Row

    ' IMPORTANTE:
    ' Excel suele dejar la ultima regla anadida como prioridad 1.
    ' Por eso aplicamos desde la ultima fila hacia la primera:
    ' asi FC_001 queda arriba del todo y FC_031 abajo.
    For r = lastRow To 2 Step -1

        activa = UCase$(Trim$(CStr(wsCFG.Cells(r, "A").Value)))
        estado = UCase$(Trim$(CStr(wsCFG.Cells(r, "R").Value)))

        If activa = "SI" And estado = "OK" Then

            rangoAplica = CStr(wsCFG.Cells(r, "E").Value)
            formulaTxt = CStr(wsCFG.Cells(r, "G").Value)

            If Left$(formulaTxt, 1) = "'" Then formulaTxt = Mid$(formulaTxt, 2)

            formulaLimpia = formulaTxt
            If TieneRefRota(formulaLimpia) Then formulaLimpia = LimpiarFormulaQuitandoBloquesRef(formulaLimpia)

            If Len(Trim$(rangoAplica)) > 0 And _
               Len(Trim$(formulaLimpia)) > 0 And _
               Not TieneRefRota(rangoAplica) And _
               Not TieneRefRota(formulaLimpia) Then

                Set rng = Nothing

                On Error Resume Next
                Set rng = wsDatos.Range(rangoAplica)
                On Error GoTo 0

                If Not rng Is Nothing Then

                    On Error GoTo ErrorRegla
                    Set fc = rng.FormatConditions.Add(Type:=xlExpression, Formula1:=formulaLimpia)
                    On Error GoTo 0

                    Call AplicarFormatoFC(fc, _
                                          CStr(wsCFG.Cells(r, "H").Value), _
                                          CStr(wsCFG.Cells(r, "I").Value), _
                                          CStr(wsCFG.Cells(r, "J").Value), _
                                          CStr(wsCFG.Cells(r, "K").Value), _
                                          CStr(wsCFG.Cells(r, "L").Value), _
                                          CStr(wsCFG.Cells(r, "M").Value))

                Else
                    wsCFG.Cells(r, "R").Value = "ERROR"
                    wsCFG.Cells(r, "S").Value = "No se pudo resolver rango aplica adaptado: " & rangoAplica
                End If

            Else
                wsCFG.Cells(r, "R").Value = "DESCARTADA"
                wsCFG.Cells(r, "S").Value = "Regla con rango/formula #REF tras adaptar."
            End If

        End If

SiguienteRegla:
    Next r

    If estabaProtegida Then Call ProtegerHoja(wsDatos)
    Exit Sub

ErrorRegla:

    wsCFG.Cells(r, "R").Value = "ERROR"
    wsCFG.Cells(r, "S").Value = "Excel no acepto la regla adaptada. " & _
                                "Rango=" & rangoAplica & ". Error: " & Err.Description

    Err.Clear
    On Error GoTo 0
    Resume SiguienteRegla

End Sub


Private Sub AplicarFormatoFC(ByVal fc As FormatCondition, _
                             ByVal colorFondo As String, _
                             ByVal colorFuente As String, _
                             ByVal negrita As String, _
                             ByVal stopIfTrue As String, _
                             ByVal tachado As String, _
                             ByVal bordeFino As String)

    Dim cFondo As Variant
    Dim cFuente As Variant

    On Error Resume Next

    cFondo = ColorDesdeTexto(colorFondo)

    If Not IsEmpty(cFondo) Then fc.Interior.Color = CLng(cFondo)

    cFuente = ColorDesdeTexto(colorFuente)

    If Not IsEmpty(cFuente) Then fc.Font.Color = CLng(cFuente)

    fc.Font.Bold = EsSi(negrita)
    fc.Font.Strikethrough = EsSi(tachado)
    fc.StopIfTrue = EsSi(stopIfTrue)

    If EsSi(bordeFino) Then
        fc.Borders(xlLeft).LineStyle = xlContinuous
        fc.Borders(xlRight).LineStyle = xlContinuous
        fc.Borders(xlTop).LineStyle = xlContinuous
        fc.Borders(xlBottom).LineStyle = xlContinuous

        fc.Borders(xlLeft).Weight = xlThin
        fc.Borders(xlRight).Weight = xlThin
        fc.Borders(xlTop).Weight = xlThin
        fc.Borders(xlBottom).Weight = xlThin
    End If

    On Error GoTo 0

End Sub


Private Function ColorDesdeTexto(ByVal texto As String) As Variant

    Dim t As String

    t = UCase$(Trim$(texto))
    t = Replace(t, "�", "A")
    t = Replace(t, "�", "E")
    t = Replace(t, "�", "I")
    t = Replace(t, "�", "O")
    t = Replace(t, "�", "U")

    Select Case t

        Case "", "SIN COLOR", "NINGUNO", "NO"
            ColorDesdeTexto = Empty

        Case "VERDE SUAVE"
            ColorDesdeTexto = RGB(198, 239, 206)

        Case "VERDE OSCURO"
            ColorDesdeTexto = RGB(0, 176, 80)

        Case "AMARILLO SUAVE"
            ColorDesdeTexto = RGB(255, 235, 156)

        Case "ROJO OSCURO"
            ColorDesdeTexto = RGB(156, 0, 6)

        Case "ROJO SUAVE"
            ColorDesdeTexto = RGB(255, 199, 206)

        Case "NEGRO"
            ColorDesdeTexto = RGB(0, 0, 0)

        Case "BLANCO"
            ColorDesdeTexto = RGB(255, 255, 255)

        Case Else
            ColorDesdeTexto = Empty

    End Select

End Function


Private Function EsSi(ByVal valor As String) As Boolean

    Dim s As String

    s = UCase$(Trim$(valor))
    s = Replace(s, "�", "I")

    EsSi = (s = "SI" Or s = "S" Or s = "TRUE" Or s = "VERDADERO")

End Function


Private Sub OcultarHojasTecnicasCFG(ByVal wb As Workbook)

    OcultarSiExiste wb, HOJA_MAPA_COLUMNAS
    OcultarSiExiste wb, HOJA_MAPA_COLUMNAS_BOB
    OcultarSiExiste wb, HOJA_MAPA_COLUMNAS_CELERGO
    OcultarSiExiste wb, HOJA_CFG_REGLAS_BOB
    OcultarSiExiste wb, HOJA_CFG_REGLAS_CELERGO
    OcultarSiExiste wb, HOJA_CFG_FORMULAS_BOB
    OcultarSiExiste wb, HOJA_CFG_FORMULAS_CELERGO

End Sub


Private Sub OcultarSiExiste(ByVal wb As Workbook, ByVal nombreHoja As String)

    If HojaExiste(wb, nombreHoja) Then
        If wb.Worksheets.Count > 1 Then
            wb.Worksheets(nombreHoja).Visible = xlSheetVeryHidden
        End If
    End If

End Sub
