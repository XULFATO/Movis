Attribute VB_Name = "Mod_GuardarArchivo"
Option Explicit

Public Sub GuardarArchivo()

    Dim ruta As Variant
    Dim nombre As String
    Dim ws As Worksheet
    Dim oldEvents As Boolean
    Dim oldAlerts As Boolean

    On Error GoTo ErrHandler

    oldEvents = Application.EnableEvents
    oldAlerts = Application.DisplayAlerts

    Set ws = Nothing

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("Analisis conceptos")
    On Error GoTo ErrHandler

    If Not ws Is Nothing Then
        nombre = CStr(ws.Range("B1").Value) & "_" & _
                 CStr(ws.Range("B2").Value) & "_" & _
                 CStr(ws.Range("B3").Value)
    Else
        nombre = ThisWorkbook.Name
        nombre = Replace(nombre, ".xlsm", "", 1, -1, vbTextCompare)
        nombre = Replace(nombre, ".xlsx", "", 1, -1, vbTextCompare)
    End If

    nombre = LimpiarNombreArchivoSeguro(nombre)

    If Len(nombre) = 0 Then nombre = "Informe"

    ruta = Application.GetSaveAsFilename( _
        InitialFileName:=nombre & ".xlsm", _
        FileFilter:="Excel con macros (*.xlsm), *.xlsm", _
        Title:="Guardar como...")

    If VarType(ruta) = vbBoolean Then
        If ruta = False Then GoTo Salida
    End If

    Application.EnableEvents = False
    Application.DisplayAlerts = False

    ThisWorkbook.SaveAs Filename:=CStr(ruta), _
                        FileFormat:=xlOpenXMLWorkbookMacroEnabled

Salida:
    Application.DisplayAlerts = oldAlerts
    Application.EnableEvents = oldEvents
    Exit Sub

ErrHandler:
    MsgBox "No se pudo guardar el archivo:" & vbCrLf & _
           Err.Number & " - " & Err.Description, vbCritical
    Resume Salida

End Sub


Private Function LimpiarNombreArchivoSeguro(ByVal s As String) As String

    Dim i As Long
    Dim ch As String
    Dim salida As String

    s = Trim$(CStr(s))

    For i = 1 To Len(s)

        ch = Mid$(s, i, 1)

        Select Case ch

            Case "<", ">", ":", Chr$(34), "/", "\", "|", "?", "*"
                salida = salida & "_"

            Case Else
                salida = salida & ch

        End Select

    Next i

    Do While InStr(1, salida, "__", vbBinaryCompare) > 0
        salida = Replace(salida, "__", "_")
    Loop

    salida = Trim$(salida)

    Do While Right$(salida, 1) = "." Or Right$(salida, 1) = " "
        salida = Left$(salida, Len(salida) - 1)
        If Len(salida) = 0 Then Exit Do
    Loop

    LimpiarNombreArchivoSeguro = salida

End Function
